---
title: "Glossar Updated"  
toc_enabled: true  
---

## Antisemitismus

„Antisemitismus ist eine bestimmte Wahrnehmung von Juden, die sich als Hass gegenüber Juden ausdrücken kann. Der Antisemitismus richtet sich in Wort oder Tat gegen jüdische oder nichtjüdische Einzelpersonen und/oder deren Eigentum sowie gegen jüdische Gemeindeinstitutionen oder religiöse Einrichtungen.“ In Deutschland haben wir aufgrund der Shoah eine besondere Verantwortung, uns mit Antisemitismus zu beschäftigen und ihn zu bekämpfen. „Darüber hinaus kann auch der Staat Israel, der dabei als jüdisches Kollektiv verstanden wird, Ziel solcher Angriffe sein.“ Wir wollen daher zwischen antisemitischer Israelkritik und legitimer Kritik an israelischer Politik differenzieren, wie wir sie auch an der Politik anderer Staaten üben würden.Teilweise aus https://www.antisemitismusbeauftragter.de/Webs/BAS/DE/bekaempfung-antisemitismus/ihra-definition/ihra-definition-node.html

## Barriere

Barrieren sind Hemmnisse, die Menschen das Leben erschweren. So können dann nicht alle Menschen an allem teilhaben. „Barrierearm“ beschreibt den Versuch, Hemmnisse zu erkennen und möglichst abzubauen. Barrierefrei zu sein wäre ein Ziel, das aber noch nicht erreicht wurde. Unser Ziel ist es Barrieren zu erkennen und möglichst abzubauen.

## BIPoC

Die folgende Definition ist von der IN*VISION https://in-vision.org/infos/faq Vielen Dank, dass wir sie verwenden dürfen.

BIPoC steht für Black, Indigenous and People of Color, also Schwarz, Indigen und Personen of Color.

Darunter werden alle Menschen gefasst, die über ein oder mehrere Elternteile Vorfahren aus Teilen des afrikanischen Kontinents, Asiens und West-Asiens haben. Deren Vorfahren Rom*nja, Sint*ezza, indigene Menschen aus Australasien, aus Nord- und Südamerika, aus der Karibik oder aus dem Raum des Indischen Ozeans sind. Nachfahren von Europäer*innen, welche aus kolonialen und imperialistischen Gründen nach Asien, Afrika oder in die Amerikas migriert sind, zählen nicht dazu.

## Braille

Oder Punktschrift ist eine tastbare Schrift, die auch ohne Sehfähigkeiten gelesen werden kann.

## Cis/cisgender

‚Cis‘ ist das Gegenstück zu ‚trans‘. ‘Cis‘ wird benutzt, um auszudrücken, dass eine Person das Geschlecht hat, dem sie bei der Geburt aufgrund der Genitalien zugewiesen wurde.

## Demokratische Selbstverwaltung

Selbstverwaltung bedeutet, dass die Initiative und Organisierung der Verwaltung von denjenigen ausgeht, für die diese Verwaltung auch bestimmt ist. Die Selbstverwaltung des BIPoC-only Zelts bedeutet also, dass alle BIPoC eigenständig dafür verantwortlich sind und auch die Freiheit haben, die Nutzung des Zeltes zu organisieren. Diese Selbstverwaltung soll demokratisch sein, das heißt alle die mitverwalten können (z.B. alle BIPoC) sollen gleichermaßen mitbestimmen können.

## DGS

Deutsche Gebärdensprache, die visuell-manuelle Sprache, in der gehörlose und schwerhörige Personen in Deutschland untereinander kommunizieren

## Drogen

Drogen sind berauschende Substanzen, die nicht vom Körper selbst gebildet werden. Dazu zählen illegale Drogen wir synthetische Drogen, Heroin oder Koks, legale Drogen wie Alkohol oder Zigaretten und halblegale Drogen wie Cannabis.

## FLINTA*

FLINTA* ist eine Abkürzung und steht für Frauen, Lesben, intergeschlechtliche, nichtbinäre, trans und agender Personen. Der angehängte Asterisk dient dabei als Platzhalter, um alle nicht-binären Geschlechtsidentitäten einzubeziehen.

## Kolonialismus

Kolonialismus bezeichnet die Ausdehnung der Herrschaftsmacht europäischer Länder auf außereuropäische Gebiete mit dem vorrangigen Ziel der wirtschaftlichen Ausbeutung. Im Zeitalter der Entdeckungen waren auch missionarische Gründe und der Handel für den Kolonialismus maßgeblich (seit der industriellen Revolution v. a. der Bezug billiger Rohstoffe); im Vordergrund stand jedoch immer die Mehrung des Reichtums der Kolonialherren und der sogenannten Mutterländer. 1914 befand sich über die Hälfte der Weltbevölkerung unter direktem kolonialen Einfluss. Insbesondere nach dem Zweiten Weltkrieg erfolgte eine weitgehende Dekolonialisierung, bei der die kolonialisierten Nationen in brutalen Kriegen ihre Freiheit erkämpfen mussten. Obwohl die ehemaligen Kolonialstaaten nun formal unabhängig waren, blieben aufgrund der geschaffenen Strukturen (künstliche Grenzen, mangelhafte Infrastruktur, einseitige wirtschaftliche Orientierung etc.) kulturelle, wirtschaftliche und andere Abhängigkeitsstrukturen bestehen.

Quelle: https://www.bpb.de/kurz-knapp/lexika/politiklexikon/17718/kolonialismus/ leicht verändert

## LGBTQ*

Abkürzung für lesbisch, schwul (englisch: gay), bisexuell, transgender und queer. Mittlerweile hat sich LGBTQ als Kurzform für alle Geschlechter, Geschlechtsidentitäten und sexuellen Orientierungen durchgesetzt, die von der zweigeschlechtlichen und heterosexuellen Normen abweichen.

Der angehängte Asterisk dient dabei als Platzhalter für intergeschlechtliche Personen, asexuelle, aromantische, agender Personen und weitere Geschlechtsidentitäten und sexuellen Orientierungen.

## Neokolonialismus

Neokolonialismus ist die Praxis, ein Land mit Hilfe von Wirtschaft (zum Beispiel sogenannte Freihandelsabkommen), Globalisierung, Kulturimperialismus und bedingter Hilfe zu beeinflussen. Typischerweise führt der Neokolonialismus zu einer Abhängigkeit, Unterwürfigkeit oder finanziellen Verpflichtung gegenüber der neokolonialistischen Nationen und transnationalen Konzerne. Dies kann zu einem unangemessenen Maß an politischer Kontrolle oder zu einer Spirale von Schulden führen, die das Verhältnis des traditionellen Kolonialismus funktional nachahmen.

Quelle: https://de.wikibrief.org/wiki/Neocolonialism verändert

## Neurodiversität

Neurodiversität ist die Idee, dass es „normal“ ist, dass Menschen ein Gehirn haben, das „anders“ funktioniert als die medizinische oder gesellschaftliche Norm. Neurodivergenz ist der Begriff für Menschen, deren Gehirne auf eine oder mehrere Arten anders funktionieren, als das, was als „normal“ oder „typisch“ nach gesellschaftlichen Normen angesehen wird. Neurotypisch ist ein beschreibender Begriff, der sich auf jemanden bezieht, dessen Gehirnfunktionen, Verhaltensweisen und Verarbeitung als „standard“ oder „typisch“ nach gesellschaftlichen Normen gelten. (https://rebellisches.org/awarenesskonzept/)

## Mansplaining

Mansplaining bezeichnet Erklärungen eines Mannes, der davon ausgeht, er wüsste mehr über den Gesprächsgegenstand als die – meist nicht-männliche – Person, mit der er spricht.

## Migration

Als Migration wird eine auf Dauer angelegte räumliche Veränderung des Lebensmittelpunktes einer oder mehrerer Personen verstanden. Migration, die über Landesgrenzen hinweg erfolgt, wird als internationale Migration bezeichnet.

## Patriarchat

Als Patriarchat wird ein Denk- und Gesellschaftssystem bezeichnet, das paternalistisch, also „von Vätern“ und gewaltvoll gegen feministische Widerstände durchgesetzt wurde. Die Idee ist, männlich markierten Personen bestimmte Wesenszüge oder Fähigkeiten zuzuschreiben, die sie von weiblich markierten Personen unterscheidet. Dabei sind die Zuschreibungen für weiblich markierte Personen durchweg kindlicher, inkompetenter, machtärmer als die Zuschreibungen männlich markierter Personen.

Um die Ideologie zu stärken wird postuliert, dass es nur zwei Geschlechter gibt und diesen bestimmte Aufgaben zugewiesen sind, was alles vereinfacht jedoch inhaltlich ohne Substanz ist. Von patriarchalen Denkmustern können die Menschen profitieren, die die Rolle so ausfüllen oder ausführen, wie sie vom Patriarchat definiert ist – Männer (und zum Teil männlich gelesene Menschen): Privilegien können ausgenutzt werden, wenn sie sich auf ihre zugewiesene Rolle reduzieren lassen möchten und sich gemäß des engen Korridors verhalten möchten. Alle anderen Menschen werden unterdrückt, besonders sobald sie jede Art von emanzipatorischem Verhalten zeigen oder weiblich oder nichtbinär markiert sind. Daher arbeiten wir daran das Patriarchat abzuschaffen und emanzipatorische, nicht-sexistische Gesellschaftsformen zu bilden.

## Queerfeminismus

Der Queerfeminismus setzt sich für die Gleichstellung und -behandlung aller Identitäten, Geschlechter, sexuellen und romantischen Orientierungen und Lebensmodelle ein. Queerfeminist*innen erkämpfen die Anerkennung für mehr Geschlechteridentitäten als cis-Frau und cis-Mann und dass Beziehungsmodelle jenseits von Heterosexualität und Monogamie ebenso valide sind. Im Queerfeminismus ist die Gleichstellung queerer Menschen eine zentrale Forderung, zusätzlich zur Gleichstellung von Frauen und Männern.

## Rassifiziert

Rassifizierung bezieht sich auf die Wissensebene von Rassismus. Rassifizierung beschreibt sowohl einen Prozess, in dem rassistisches Wissen erzeugt wird, als auch die Struktur dieses rassistischen Wissens.

## Rassismuskritik & rassismuskritische Praxis

Rassismuskritik geht von der Annahme aus, dass Rassismus eine gesellschaftliche Normalität darstellt, insofern alle Menschen durch rassistische Kategorisierungen, Zuschreibungen und Diskriminierungen in unserer Gesellschaft positioniert werden. Ein Handeln ist also nur innerhalb dieser Verhältnisse möglich. Daher kann Rassismus nur in ihrem Rahmen bekämpft, Zugehörigkeitsordnungen können verschoben und rassistische Diskriminierungen abgebaut werden. Dabei ist die Positionierung der Akteur*innen zu berücksichtigen, um nicht erneut rassistische Strukturen der Über- und Unterordnung zu stützen.

Insofern ist Rassismuskritik eine (selbst)reflexive, theoriegebundene, widersprüchliche und prinzipiell nicht abschließbare Praxis. Dadurch setzt sich Rassismuskritik ausdrücklich von Haltungen und Handlungsformen ab, die auf der Annahme beruhen, es reiche aus, für Gleichheit und gegen Rassismus einzutreten, um nicht rassistisch zu sein – z.B. Antifa. Denn sie blenden rassistische Strukturen aus und sind daher auch blind für die Folgen der eigenen Praxis.

(Definition von Informations- und Dokumentationszentrum für Antirassismusarbeit e. V. (IDA) https://tinyurl.com/muscxy4u)

## Raum

Wir benutzen of Redewendungen wie „Raum nehmen“ oder „Raum schaffen“. Mit „Raum“ meinen wir das unmittelbare soziale Umfeld einer Person. Eine Person, die sich „Raum nimmt“, verschafft sich die Aufmerksamkeit der Menschen um sie herum. Das kann sowohl bestärkend sein, wenn die Person ansonsten zu wenig Aufmerksamkeit erhält, aber auch störend, wenn sie damit anderen zu viel Aufmerksamkeit entzieht. „Raum schaffen“ ist die Bemühung, dass das soziale Umfeld gewissen Handlungen ermöglicht oder ahndet. Wenn Raum für Kritik geschaffen wird, soll ermöglicht werden, Kritik zu äußern ohne dafür ausgeschlossen zu werden. Das Schaffen eines rassismuskritischen Raums bedeutet wiederum, dass rassistische Aussagen und Handlungen vom Umfeld kritisiert werden.

## Reflektieren/Selbstreflexion

Reflektieren/Selbstreflexion bezeichnet die Tätigkeit, über sich selbst nachzudenken.

Das bedeutet, sein Denken, Fühlen und Handeln zu analysieren und zu hinterfragen mit dem Ziel, mehr über sich selbst herauszufinden. Dabei können wir uns nicht nur selbst als individuelle Person hinterfragen, sondern auch als Teil eines Systems, zum Beispiel als Teil eines Camps oder einer politischen Organisation.

## Repression

Repression geht von staatlichen Behörden, wie der Polizei oder von Gerichten aus und kann z.B. körperliche Gewalt sein, aber auch die rechtliche Verfolgung und Bestrafung von politischem Aktivismus. Repression ist ein Mittel zur Aufrechterhaltung gesellschaftlicher Herrschaftsverhältnisse. Auch und insbesondere in der Reproduktion von Diskriminierung, wie z.B. Rassismus.

## Solidarität

Solidarität bezeichnet das Prinzip gegen die Vereinzelung und ist die Zusammengehörigkeit, und die gegenseitige (Mit-)Verantwortung und (Mit-)Verpflichtung.

## Trans

Menschen, die nicht das Geschlecht sind, das ihnen bei der Geburt zugewiesen wurde, sind trans. Trans Menschen können sowohl binär (also Mann oder Frau) als auch nichtbinär sein.

Nicht alle Menschen, auf die dies zutrifft, bezeichnen sich selbst so – das Label sollte also wie immer anderen Menschen nicht übergestülpt werden. Trans wird häufig als Selbstbezeichnung verwendet.

## weiß / weißsein/ weiß positioniert

weiß bzw. weißsein bzw. weiß positioniert bezeichnen ebenso wie der Begriff PoC keine biologische Eigenschaft, sondern eine politische und soziale Konstruktion. Mit weißsein ist die dominante und privilegierte Position in dem Machtverhältnis Rassismus gemeint. Sie bleibt häufig unausgesprochen und unbenannt, obwohl zu jeder Diskriminierung sowohl eine diskriminierte, als auch eine privilegierte Position gehören. Im Gegensatz zu dem Begriff BIPoC ist weiß keine Selbstbezeichnung.

Um deutlich zu machen, dass weißsein keine ermächtigende Selbstbezeichnung, schreiben wir das weiß klein und kursiv, im Gegensatz zu der empowernden Selbstbezeichnung Schwarz, welche wir groß und nicht-kursiv schreiben.

## Safer Space
Ein Safer Space ist ein Ort, in dem sich marginalisierte oder diskriminierte Menschen sicher fühlen können.
