---
title: 'Spenden'
description: 'Unterstütz uns ein gutes camp für alle zu organisieren'
---

### Geldspenden: 

Auch in diesem Jahr haben wir wieder viele Ausgaben rund ums Camp. Von Zelten über Klos bis hin zu Strom haben wir viele Mietkosten. Dabei versuchen wir so viel wie möglich kostengünstig bis kostenlos zu organisieren, das klappt aber nicht bei allem. Zusätzlich versuchen wir, das Camp auch mit Anträgen bei Stiftungen o.ä. zu finanzieren, sind aber zur kompletten Finanzierung auf Spenden angewiesen.

Wir haben eine Crowdfunding-Kampagne gestartet!
Die halbe Limousine des Oberbürgermeisters – das würde schon reichen um unser Camp für 1500 Menschen zu finanzieren.
Also eigentlich ein Schnäppchen! Da wir aber leider keinen Zugriff auf Dieter Reiters Luxus-Auto haben, brauchen wir
euch, denn viele Rechnungen müssen wir schon vor Beginn des Camps bezahlen.
Spenden könnt ihr hier: http://betterplace.org/p125299

Verbreitet unsere Crowdfunding-Kampagne auch gerne weiter!
Vielen Dank! 🙂

### Spendenkonto:

Wenn du dabei helfen möchtest unser Camp stattfinden zu lassen und den Aktivist*innen eine Teilnahme unabhängig vom jeweiligen Geldbeutel zu ermöglichen, kannst du auch auf dieses Konto spenden:

|                  |                                                        |
|------------------|--------------------------------------------------------|
| Verwendungszweck | mobilitätswendecamp                                    |
| Kontoinhaber     | Deutscher Förderverein globaler grüner Bewegungen e.V. |
| IBAN             | DE72430609671115855900                                 |
| BIC              | GENODEM1GLS                                            |
