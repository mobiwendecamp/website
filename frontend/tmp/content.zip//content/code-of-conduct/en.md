---
title: "Code of Conduct"
---
Basically:

We reserve the right to exclude persons and groups who belong to right-wing extremist parties or organizations, who can be assigned to the right-wing extremist scene or who have already appeared in the past through racist, nationalist, anti-Semitic or other inhuman statements from playing in the program tents. Political party advertising or political party events of any kind are also excluded.



What is important for visitors?

If you are challenged by program content, contact the awareness team for support.

If you wish to talk to the presenters about problematic content, contact the awareness team for support.



What is important to us for curating groups?

We understand curating groups to be groups that help shape the program. We would like them to:

The passing on and confirmation of the Code of Conduct (this text) to the speakers.
The passing on and confirmation of the Awareness Concept to/by the speakers.
Intervention in the event of violations of the Code of Conduct and the awareness concept (currently only in German),  short version in english follows and at the camp).
A program that is not predominantly white-cis-male.
The marking of whether a room is open or closed. People can still join an open room after it has started, but not in closed rooms.
An intentional communication to those visiting. In particular, this includes trigger cues and appropriate language that is accessible to as many as possible.
Adherence to assembly guidelines, for example, nighttime quiet.
Some flexibility in case of disruptions in the schedule. There may be changes in lecture and meal times, or spontaneous (emergency) plenaries may be called.
A solidary handling of (funding) money. We want to avoid the reproduction of the precariat, e.g. the gender-pay-gap. In doing so, we are aware that volunteers per se are precariously organized.
Bringing in other needs, both in terms of coordinating the program with other groups, and for the speakers in each case. If a group is still missing an important point in the Code of Conduct or in the Awareness Concept, please let us know in a timely manner. Then we can discuss the points and incorporate them by consent.
What do we want from the speakers?

Avoid uncritical reproduction of power constructs and stereotypes such as the gender binary of women and men.
Trigger notes for the content, when topics like violence are part of the content.
Allow sufficient breaks for the length of the program item and consider meal times if necessary.
Communicate own needs for lecture space and time at camp early. Examples include barrier-free needs or childcare.
Read and agree to the Awareness Concept (currently only in German,  short version in english follows and at the camp).
What happens if Code of Conduct is not respected?

We reserve the right to interrupt content if participants turn to the Awareness AG in confidence because the Awareness Concept has not been respected.
How would you like to handle such a case? Please answer in the next question.
