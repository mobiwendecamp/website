---
title: "Verhaltenscodex"
---
Grundsätzlich:

Wir behalten uns vor, Personen und Gruppen, die rechtsextremen Parteien oder Organisationen angehören, die der rechtsextremen Szene zuzuordnen sind oder bereits in der Vergangenheit durch rassistische, nationalistische, antisemitische oder sonstige menschenverachtende Äußerungen in Erscheinung getreten sind, von der Bespielung der Programmzelte auszuschließen. Auch Partei-Werbung oder Partei Veranstaltungen jeglicher Art sind ausgeschlossen.



Was ist wichtig für Besucher*innen?

Wenn du von Programminhalten herausgefordert bist, wende dich vertrauensvoll ans Awareness-Team.

Wenn du dir bei problematischen Inhalten ein Gespräch mit den Vortragenden wünscht, wend dich für Unterstützung ans Awareness-Team.



Was ist uns wichtig für kuratierende Gruppen?

Als kuratierende Gruppen verstehen wir Gruppen, die das Programm mitgestalten. Wir wünschen uns von ihnen:

Die Weitergabe und Bestätigung des Codes of Conduct (dieser Text) an/durch die Referierenden
Die Weitergabe und Bestätigung des Awareness-Konzepts an/durch die Referierenden.
Das Einschreiten bei Verstößen gegen den Code of Conduct und das Awareness-Konzept
Ein nicht überwiegend weiß-cis-männlich besetztes Programm
Die Kennzeichnung, ob ein Raum offen oder geschlossen ist. In einen offenen Raum können auch nach dem Beginn noch Leute dazustoßen, bei geschlossenen Räumen nicht.
Eine bewusste Kommunikation an die Besuchenden. Insbesondere fallen darunter Trigger-Hinweise und eine angemessene, für möglichst alle zugängliche Sprache.
Die Einhaltung der Versammlungsrichtlinien, zum Beispiel die Nachtruhe.
Etwas Flexibilität bei Störungen im Ablauf. Es kann zu veränderten Vortrags- und Essenszeiten kommen oder spontane (Notfall-)Plena einberufen werden.
Einen solidarischen Umgang mit (Förder-)Geldern. Wir wollen die Reproduktion des Prekariats, z.B. der Gender-Pay-Gap, vermeiden. Dabei ist uns klar, dass Ehrenamtlich eper se prekär organisiert sind.
Das Einbringen weiterer Bedürfnisse, sowohl in Bezug zur Abstimmung des Programms mit anderen Gruppen, als auch für die jeweils Referierenden. Wenn einer Gruppe noch ein wichtiger Punkt im Code of Conduct oder im Awareness-Konzept fehlt, teilt uns das gerne zeitnah mit. Dann können wir die Punkte noch diskutieren und im Konsens einbauen.
Was wünschen wir uns von den Referierenden?

Vermeidung kritikloser Reproduktion von Machtkonstrukten wie zum Beispiel dem Gender-Binary von Frau und Mann.
Trigger-Hinweise für die Inhalte
Ausreichend Pausen für die Länge des Programmpunktes einplanen und ggf. Essenszeiten beachten.
Eigene Bedürfnisse an den Vortragsraum und die Zeit auf dem Camp frühzeitig mitteilen. Beispiele sind Barrierearmut oder Kinderbetreuung.
Lesen und Zustimmen des Awareness-Konzepts.
Was passiert wenn Code of Conduct nicht respektiert wird?

Wir behalten uns vor Inhalte zu unterbrechen, weil das Awareness Konzept nicht respektiert wurde.
Wie möchtest du gerne in so einem Fall unterbrochen werden?
