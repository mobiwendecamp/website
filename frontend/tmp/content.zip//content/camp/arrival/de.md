---
title: "Anreise" # Some Comment
description: "Wie kommst du zum Camp hin und wieder vom Camp weg."
hero_image: "hero_2.jpg"
toc_enabled: true
---

## Generelles

Die Anreise findet selbstorganisiert statt. Nach München kommt ihr gut mit dem Zug und Reisebus. Einige der nach München mobilisierenden
Gruppen werden wahrscheinlich gemeinsam Anfahrten organisieren. Haltet euch dazu bei den jeweiligen Gruppen auf dem Laufenden. Achtet außerdem
darauf, möglichst mit der Bezugsgruppe anzureisen, mit der ihr dann auch auf dem Camp seid.

Das Camp findet im Luipoltpark statt.

Adresse: **Brunnerstraße 2, 80804 München**

Wenn du vor deiner Anreise weitere Fragen hast, die nicht auf dieser Seite beantwortet werden, kannst du uns gerne ein Mail schreiben

<Map lat="48.168780" long="11.570189">  
<Marker lat="48.16928579811221" long="11.570031170554842" title="Infozelt" />  
</Map>

## Sichere An- und Abreise

Wir wollen allen Menschen eine möglichst sichere An- und Abreise ermöglichen.
Wenn du dich auf dem Weg zum Camp unsicher fühlst, melde dich gerne bei uns, um eine Begleitperson anzufordern, die dich an einem von dir gewünscht Ort abholt und zum Camp begleitet.

Bitte melde dich dafür bei der Assistenz-AG, entweder vorab unter assistenz_iaa@systemli.org oder spontan unter *+49 176 95167978*.

Wenn du dich beim Verlassen des Campgeländes unsicher fühlst, kannst du dich auch beim Disability Pride-Pavillon für eine Begleitperson melden.

## Anreise mit dem Auto

Wir wünschen uns, dass ihr nicht mit dem Auto oder Campingbus anreist, es wird vor Ort keine Parkmöglichkeiten geben. Falls ihr mit einem Rollstuhl anreist, befinden sich in der Belgradstraße 115 (ohne Zeitbegrenzung) sowie in der Belgradstraße 106/108 (bis zu fünf Stunden) je zwei ausgewiesene Parkplätze für Menschen mit Behinderung.

Ein Inklusionstaxi für die Sitzendbeförderung von Menschen im Rollstuhl kann z.B. bei dem Münchner Rollstuhltaxi (*+49 89 84938828*), bei Isarfunk (*+49 89 450 540*) oder bei Taxi München (*+49 89 21610*) bestellt werden.

Falls ihr weiterführende Fragen zur barrierearmen Anreise habt, meldet euch gern bei der Assistenz-AG, vorab unter assistenz_iaa@systemli.org oder spontan unter +49 176 95167978.

## Anreise mit dem ÖPNV

Am nächsten befinden sich die Haltestellen Scheidplatz (U2, U3, Tram 28, Tram 12) und Ackermannstraße (Tram 27).

Beim U-Bahnhof Scheidplatz beträgt die Ein- und Ausstiegshöhe zwischen Fahrzeugboden und Bahnsteig 10 cm. Rolltreppen und ein Aufzug sind vorhanden.

Zur Planung der Anfahrt kann die Fahrplanauskunft der MVV genutzt werden. Dort lassen sich auch besondere Routenoptionen und Handicaps vermerken. Für Menschen mit Sehbehinderung steht die Auskunft in einer vereinfachten Version zur Verfügung. Alternativ lassen sich Fahrplanauskünfte auch über die Telefonnummer *+49 89 41 42 43 44* erfragen. Für ältere Endgeräte steht zudem eine stark vereinfachte Fahrplanauskunft zur Verfügung.