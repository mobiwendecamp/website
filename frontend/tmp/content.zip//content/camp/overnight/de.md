---
title: "Übernachtung" # Some Comment
description: "Zusammen Leben"
---

## Schlafen

Auf unserem Camp wird es große Flächen geben, auf denen ihr von euch mitgebrachte Zelte aufbauen könnt.
Auf unseren Zeltflächen sind die Breiche A-G ausgewiesen. Bestimmte Flächen davon sind für [Safer Spaces](https://mobiwende.camp/glossar#safer-space) reserviert.
Wenn du am Camp ankommst, informiere dich bitte am Infopoint über die Aufteilung der Zeltwiese.

## Sanitäre Einrichtungen

Wir bieten auf dem Camp Toiletten sowie Möglichkeiten zum Duschen an, die kostenlos genutz werden können.

## Verletzungen und Infektionsschutz

Es gibt ein umfassendes Hygienekonzept, das Infektionskrankheiten abdeckt und eine Sanicrew, die sich um mögliche Verletzungen kümmern kann.