---
title: "Mitmachen"
hero_image: "hero_7.jpg"
---

Du hast bestimmte Wünsche ans NoIAA Mobiwendecamp 2025 und magst Verantwortung übernehmen diese mit umzusetzen? Du hast Lust in den Bereichen Programm, Awareness, Öffentlichkeitsarbeit oder Infrastruktur das Camp mitzuorganisieren? Wir freuen uns immer über weitere motivierte Menschen, auch ohne Vorerfahrung, denn nur gemeinsam können wir so ein großes Camp stemmen! Schreib uns bei Interesse gern eine Mail an mobilitaetswende_camp_muenchen@riseup.net

## Bei auf oder Abbau helfen

Zelte, Wasser/Abwasser, Strom, Sitzgelegenheiten, Sonnenschutz usw… wollen auf-und abgebaut werden. Dabei kannst du viele coole, neue Skills zum Thema Logistik und Infrastruktur lernen und dich am Ende des Aufbaus darüber freuen, dass alle mit Wasser versorgt sind und ein Dach über dem Kopf haben. Der Aufbau beginnt am **05.09.25** und geht bis zum Beginn des Camps am **09.09.25**.
Der Abbau beginnt dann nach dem Camp am **15.09.25** und geht bis zum **16.09.25**.