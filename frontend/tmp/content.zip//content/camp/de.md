---
title: "Camp" # Some Comment
description: "Alles über das Camp, unsere Motivationen und Visionen für 2025"
toc_enabled: true
---

## Was ist das Camp?

Vom **09.09.25** bis **14.09.25** wird das Camp wieder parallel zur IAA in München stattfinden.

Mit unserem „Mobilitätswende Camp München“ wollen wir solidarische Praxis direkt erfahrbar machen und ein möchten Bildungsangebot und vernetzendes Element für die Klimabewegung sein. Utopien einer demokratischeren und gerechteren Welt sollen hier weiter entwickelt und in die Praxis geführt werden. Das Camp wird für ca. 1.500 Menschen Zeltmöglichkeiten, Toiletten, Küchen und Support-Strukturen bieten.

Außerdem erwarten euch spannende Workshops, leckeres Essen, gute Musik und vor allem: sehr nette Menschen. Kommt vorbei! Wir freuen uns, euch (wieder-)zusehen und über Anregungen, Fragen, Gespräche und jede helfende Hand.

## Was erwartet dich auf dem Camp?

- Reichhaltiges Workshopprogramm
- Musik und andere Acts
- Gutes Essen
- Verschiedenste Gäst:innen mit Podiunms Diskussionen, Vorträgen und Unterhaltung
- Nette, offene Menschen die zusammen für eine solidarische Mobilitätswende kämpfen und sich austauschen

## Wie leben wir auf dem Camp zusammen?

- Wir organisieren uns selbst und übernehmen gemeinsam Verantwortung für das Camp – die Arbeit (Schnippeln, Toiletten putzen, Müll entsorgen, Nachtschichten) übernehmen wir gemeinsam, es gibt keinen Dienstleister
- Das Campleben wird gemeinsam in morgentlichem Plenum organisiert
- Wir wollen gemeinsam darauf achten, dass sich alle wohlfühlen und gehen respektvoll, empathisch und wohlwollend miteinander um

## Warum gibt es das Camp?

Das Jahr 2025 hat es in sich: Wir werden das 1,5 Grad-Ziel verfehlen, rechte Bewegungen sind in Deutschland so stark wie zuletzt vor 80 Jahren,
aufgrund der schwächelnden Wirtschaft droht in Deutschland die soziale Schere weiter auseinander zu gehen, und in einem überhitzten politischen Diskurs werden linke Bewegungen systematisch diskreditiert.

Auch dieses Jahr findet die "Internationale Automobilitäts-Austellung" (IAA) in München statt. Unter dem Motto "Mobility" wird nunmehr zum dritten Mal die Stadt und ihr öffentlicher Raum von der Autoindustrie als billiges Schaufenster genutzt. Doch wir möchten der profitgetriebenen Autoindustrie nicht die Deutungshoheit über die Zukunft der Mobilität überlassen. Deshalb veranstalten wir auch 2025 wieder das Mobilitätswendecamp im Luitpoldpark. Hier findet ihr wieder Raum für Informationen, Vorträge und Diskussionen zu den Themen Umwelt & Nachhaltigkeit. Wir wollen dem aktuellen Rechtsruck etwas entgegenzusetzen, weshalb sich das Programm des Camps dieses Jahr verstärkt der Zivilgesellschaft, dem Widerstand gegen Rechts und gegen Desinformation widmet.

## Wie wird das Camp organisiert?

Das Mobilitätswendecamp ist ein kollektiver und unabhängiger Raum. Wir organisieren uns selbst und beschäftigen keine Dienstleister. Das Camp entsteht deshalb nur durch Ehrenamt. Ganz konkret durch Hilfe beim Aufbau und Abbau vor Ort, durch Übernahme von Helfer:innentätigkeiten im Camp, und beim Organisieren im Vorfeld. Wir sind deshalb immer offen für deine Unterstützung. [Hier erfährst du mehr darübe wie du uns unterstützen kannst](https://mobiwende.camp/camp/participate).