---
title: "Zugänglichkeit und Assistenz" # Some Comment
description: "Infos zu Zugänglichkeit, Assistenz und Barriere abbau."
---

## Kontakt

Bei Fragen zu Barrieren auf dem Camp sowie zu allen weiteren Punkten auf dieser Seite kannst du uns wie folgt zu erreichen:

> **Email** :

> **Telefon**:

Die Menschen, die sich hierum kümmern sind von vielen Barrieren selbst nicht betroffen, daher sind wir dankbar über Rückmeldungen zu
Bedürfnissen aus Betroffenen-Perspektive! Dieses Jahr sind unsere Kapazitäten recht begrenzt, was wir noch umsetzen können. Wir nehmen eure
Rückmeldungen aber auch mit ins nächste Jahr und in andere Camp-Orga-Kontexte!

Du hilfst uns, wenn du uns vorab über dich häufig hemmende Barrieren informierst. Vielen Dank!

## Generelles

Der Disability Pride-Pavillon ist ein Ort zum Reden, Spielen und Vernetzen. Wenn du dich ausruhen möchtest, gibt es dafür im Nordwesten des Camps ein reizarmes Zelt, in dem du wieder Kraft sammeln kannst. Außerdem gibt es einen ruhigen Zeltbereich.

Wir bieten bei Bedarf eine Führung über das Camp an. Dabei werden wir alle wichtigen Orte einmal ablaufen und es gibt Gelegenheit Fragen zum Camp zu stellen.

Sprich uns an, falls du nicht auf dem Camp schlafen kannst, Medikamente kühl aufbewahren musst oder wir dir in anderen Bereichen das Leben leichter machen können.

## Kinderbetreuung

Oft verlassen Menschen politische Arbeit, wenn sie Kids bekommen. Da möchten wir gegensteuern und Leuten die Möglichkeit geben auch am Programm teilzunehmen.