
There will be large areas on our camp where you can set up your own tents.

Important when arriving at the camp:

Areas A-G are our designated sleeping tent areas. Certain areas of these are reserved for Safer Spaces. When you arrive at camp, please check the info point for the layout of the tent area.

(A Safer Space is a place where marginalized or discriminated people can feel safer).
