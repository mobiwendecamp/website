---
title: "Essen und Trinken" # Some Comment
description: "A modal dialog that interrupts the user with important content and expects a response."
---

ICH bin voll Englisch

Wir werden vom befreundeten Kochkollektiv Knoblauchfahne bekocht. Sie machen Frühstück, Mittag- und Abendessen und kochen grundsätzlich vegan.
![Logo des Knoblauchfahne-Kollektivs](.attachments/Knoblauchfahne-648x1024.png "Ein gekreuztes Hackebeil und ein Hammer unter einer Knoblauchknolle")



Die Küche ist als Mitmachküche konzipiert. Zwar dürfen wegen Hygieneauflagen nicht alle Personen an den Töpfen stehen, doch von Abspülen über Schnibbeln bis hin zur Ausgabe wird tatkräftiges mithelfen nötig sein. Schnappt euch also eure Bezugsgruppe und diskutiert wie ihr euch auf dem Camp einbringen wollt, sei es Küche oder etwas anderes. Solltet ihr euch für eine Küchenschicht entscheiden, kommt einfach vorbei und fragt ob und wo gerade Hilfe gebraucht wird. Die Küche wird sich auch wenn Unterstützung dringend nötig ist auf dem Camp bemerkbar machen.

Lebensmittelunverträglichkeiten
Wenn ihr eine Lebensmittelunverträglichkeit oder Allergie habt dann meldet euch bitte frühzeitig, am besten anonym über (link:formular website). Auch vor Ort könnt ihr eure Allergien in den Allergiebriefkasten am Infopoint werfen. Je besser die Küche Bescheid weiß, desto genauer kann abgestimmt werden wie gekocht wird. Nach Möglichkeit wird um auf Unverträglichkeiten Rücksicht zu nehmen separates Essen zubereitet.

Finanzierung
Sie finanzieren die Lebensmittel und das Equipment dabei über Spenden, die vor Ort eingesammelt werden. Wenn ihr es euch leisten könnt, gebt gern etwas mehr als ihr meint in den Topf um jene solidarisch mitzufinanzieren die weniger haben. Solltet ihr vor Ort beispielsweise kein Bargeld mitführen, sind spenden für die Küche auch über (link:paypal) möglich.

Kontakt
Solltet ihr auf dem Camp längerfristig in der Küche mitarbeiten wollen oder habt ihr noch Fragen oder Anregungen, meldet euch beim Kontaktformular auf
https://linktr.ee/knoblauch.fahne
