---
title: "Presse Spiegel 2021"
description: "Alle artikel über das Mobiwende camp aus dem Jahr 2021"
---

## 11.10.2021

- https://www.abendzeitung-muenchen.de/muenchen/iaa-in-muenchen-neues-protestcamp-gegen-automesse-2023-art-762738
- https://www.sueddeutsche.de/muenchen/muenchen-iaa-2023-neuauflage-1.5436210

## 08.10.2021

- https://www.abendzeitung-muenchen.de/muenchen/das-steht-in-den-geheimvertraegen-der-iaa-art-761940

## 07.10.2021

- https://www.abendzeitung-muenchen.de/muenchen/krach-im-stadtrat-iaa-2023-bleibt-wohl-auf-ganz-muenchen-verteilt-art-761673

## 14.09.2021

- https://www.abendzeitung-muenchen.de/muenchen/iaa-einsatz-anwaelte-kritisieren-vorgehen-der-polizei-art-756266
- https://www.merkur.de/bayern/iaa-muenchen-bayern-polizei-einsatz-staatsregierung-herrmann-gruene-auto-zr-90980793.html

## 13.09.2021

- https://www.sueddeutsche.de/muenchen/muenchen-iaa-rathaus-streit-1.5409139
- https://www.br.de/nachrichten/bayern/polizeieinsatz-bei-iaa-demo-landtags-gruene-fordern-aufklaerung,SiuJw0e

## 12.09.2021

- https://www.sueddeutsche.de/muenchen/muenchen-iaa-bilanz-kommentar-1.5407819
- https://www.abendzeitung-muenchen.de/muenchen/umweltaktivisten-kritisieren-vorgehen-der-polizei-noch-nie-hatte-ich-so-angst-art-756056

## 11.09.2021

- https://www.br.de/mediathek/video/br24-rundschau-1830-11092021-csu-parteitag-viel-applaus-fuer-laschet-av:610aa23b107aca000732727d
- https://www.tvnow.de/shows/rtl-aktuell-33/2021-09/episode-254-sendung-vom-11-09-2021-4163337
- https://www.abendzeitung-muenchen.de/muenchen/az-newsblog-no-iaa-am-samstag-polizei-zieht-erste-bilanz-art-755517
- https://www.spiegel.de/wirtschaft/unternehmen/iaa-2021-in-muenchen-tausende-demonstrieren-gegen-automesse-a-b2790f4b-85e4-48c1-8b99-60c5719a022a
- https://www.sueddeutsche.de/muenchen/muenchen-iaa-demos-theresienweise-koenigsplatz-pfefferspray-1.5405834
- https://www.sueddeutsche.de/muenchen/muenchen-iaa-greenwashing-proteste-bilder-1.5407572
- https://www.merkur.de/wirtschaft/iaa-muenchen-demonstration-proteste-autos-polizei-theresienwiese-raddemo-news-aktuell-zr-90974975.html
- https://taz.de/Proteste-gegen-die-IAA-in-Muenchen/!5800110/
- https://www.deutschlandfunk.de/muenchen-sternfahrt-und-protest-gegen-automobilkonzerne.1939.de.html?drn:news_id=1300389
- https://www.deutschlandfunk.de/muenchen-radlerdemo-und-protestzug-gegen-automobilkonzerne.2932.de.html?drn:news_id=1300446
- https://www.augsburger-allgemeine.de/bayern/Anti-IAA-Demonstration-Tausende-protestieren-IAA-Demo-in-Muenchen-erreicht-ihren-Hoehepunkt-id60526201.html
- https://www.gmuender-tagespost.de/welt/wirtschaft/iaa-muenchen-news-demonstration-proteste-autos-polizei-aktuell-zr-90972509.html

## 10.09.2021

- https:// Twitter Trend Deutschland #3 „#BlockIAA“
- https://www.br.de/nachrichten/bayern/iaa-umweltverbaende-kritisieren-stadt-muenchen-scharf,SicQLob
- https://www.sat1.de/regional/bayern/nachrichten/die-sendung-vom-10-09-2021-ganze-folge
- https://www.sueddeutsche.de/muenchen/muenchen-iaa-proteste-polizei-1.5406838
- https://www.sueddeutsche.de/muenchen/iaa-proteste-bilder-1.5406903
- https://www.sueddeutsche.de/meinung/iaa-autoindustrie-kommentar-muenchen-polizei-1.5407363
- https://www.sueddeutsche.de/muenchen/muenchen-iaa-polizei-proteste-1.5405659
- https://www.sueddeutsche.de/muenchen/muenchen-iaa-pfefferspray-polizei-odeonsplatz-1.5405834
- https://www.sueddeutsche.de/muenchen/muenchen-iaa-polizei-journalisten-protestcamp-1.5405834
- https://www.sueddeutsche.de/meinung/iaa-autoindustrie-kommentar-muenchen-polizei-1.5407363?reduced=true
- https://www.abendzeitung-muenchen.de/muenchen/az-newsblog-block-iaa-demo-aktivisten-blockieren-weitere-plaetze-in-der-stadt-art-755517
- https://www.abendzeitung-muenchen.de/muenchen/iaa-proteste-in-muenchen-verkehrschaos-am-samstag-erwartet-auch-beim-oepnv-art-755276
- https://www.br.de/nachrichten/bayern/polizei-geht-mit-schlagstoecken-gegen-iaa-demonstranten-vor,SiavXCZ
- https://taz.de/Aktionen-gegen-Automesse-IAA/!5800060/
- https://taz.de/Berichterstattung-ueber-die-IAA-Proteste/!5800081&s=iaa/
- https://taz.de/Archiv-Suche/!5797084&s=iaa&SuchRahmen=Print/
- https://taz.de/Archiv-Suche/!5797033&s=iaa&SuchRahmen=Print/
- https://www.heise.de/tp/features/Ausgebremste-Autoshow-6189695.html
- https://www.mucbook.de/hausbesetzung-und-pfefferspray-protest-gegen-die-iaa-eskaliert-muenchen/
- https://www.zeit.de/politik/deutschland/2021-09/automesse-iaa-mobility-muenchen-aktivisten-besetzen-haus
- https://www.tz.de/muenchen/stadt/iaa-muenchen-proteste-carola-rackete-haus-besetzung-news-aktuell-polizei-hubschrauber-90972701.html
- https://www.tz.de/muenchen/stadt/iaa-muenchen-proteste-demo-sperrungen-kvr-zr-90970374.html
- https://www.tz.de/muenchen/stadt/hallo-muenchen/iaa-proteste-chaos-muenchen-haus-karlstrasse-bluelane-polizei-aktivisten-autobahn-pfefferspray-theresienwiese-90973822.html
- https://www.tz.de/muenchen/stadt/iaa-muenchen-proteste-klimaaktivisten-polizei-demonstrationen-krawalle-zr-90974361.html
- https://www.merkur.de/wirtschaft/iaa-muenchen-news-demonstration-proteste-autos-aktuell-zr-90972509.html
- https://www.spiegel.de/wirtschaft/unternehmen/muenchen-polizei-geht-mit-schlagstoecken-gegen-anti-iaa-demonstranten-vor-a-0874804c-83e5-428d-b953-22819f9cf349
- https://www.tagesspiegel.de/politik/proteste-gegen-iaa-polizei-setzt-schlagstoecke-und-pfefferspray-gegen-demonstrierende-ein/27601356.html
- https://www.faz.net/aktuell/feuilleton/medien/proteste-bei-iaa-taz-journalist-von-polizei-festgehalten-17532047.html
- https://de.euronews.com/2021/09/10/klimakiller-party-proteste-gegen-automesse-iaa-2021-in-munchen
- https://www.stern.de/wirtschaft/schlagstoecke-und-hausbesetzungen–proteste-gegen-die-iaa-eskalieren-30731852.html
- https://www.t-online.de/nachrichten/deutschland/id_90777582/automesse-proteste-gegen-iaa-zusammenstoesse-und-pfefferspray.html
- https://www.rnd.de/wirtschaft/iaa-proteste-in-muenchen-polizei-setzt-pfefferspray-und-schlagstock-ein-GR3P63NICRADXHK3ZXKYKNSOIQ.html
- https://www.handelsblatt.com/unternehmen/industrie/internationale-automobilausstellung-proteste-gegen-iaa-polizei-setzt-schlagstoecke-und-pfefferspray-ein/27596298.html
- https://www.automobilwoche.de/article/20210910/AGENTURMELDUNGEN/309109974/polizei-setzt-schlagstocke-ein
- https://www.freiepresse.de/nachrichten/deutschland/proteste-gegen-iaa-polizei-setzt-schlagst-cke-ein-artikel11707068
- https://www.rnz.de/topthemen_artikel,-automesse-proteste-gegen-iaa-11zusammenstoesse-und-pfefferspray-_arid,736351.html
- https://www.fnp.de/wirtschaft/iaa-muenchen-news-demonstration-proteste-autos-aktuell-zr-90972509.html

## 09.09.2021

- https://www.sueddeutsche.de/muenchen/muenchen-iaa-gegner-theresienwiese-uebung-polizei-1.5405661?reduced=true
- https://www.abendzeitung-muenchen.de/muenchen/iaa-gegner-proben-auf-der-theresienwiese-fuer-die-konfrontation-mit-der-polizei-art-755397
- https://taz.de/Stoerer-bei-Automesse-in-Muenchen/!5795867&s=iaa/

## 08.09.2021

- https://www.mucbook.de/zentrum-des-protests-das-mobilitaetswende-camp-auf-der-theresienwiese

## 07.09.2021

- https://www.sueddeutsche.de/muenchen/muenchen-iaa-protestcamp-kommentar-1.5402250
- https://www.sueddeutsche.de/muenchen/muenchen-iaa-protest-camp-theresienwiese-aufbau-1.5403273
- https://rsw.beck.de/aktuell/daily/meldung/detail/vg-muenchen-iaa-protestcamp-gericht-erlaubt-feldkueche-fuer-alle
- https://www.tz.de/muenchen/stadt/hallo-muenchen/muenchen-iaa-protestcamp-theresienwiese-auflagen-kvr-verwaltungsgericht-eilantrag-versammlung-90966606.html

## 06.09.2021

- https://www.sueddeutsche.de/muenchen/muenchen-iaa-protestcamp-eilantrag-1.5402243
- https://www.zeit.de/news/2021-09/06/eilantrag-gegen-behoerdliche-auflagen-fuer-iaa-protestcamp
- https://www.br.de/nachrichten/bayern/gericht-zu-iaa-protestcamp-kein-zirkuszelt-nur-eine-feldkueche,SiFI3Ll
- https://www.merkur.de/lokales/muenchen/stadt-muenchen/eilantrag-und-klage-gegen-protestcamp-auf-der-theresienwiese-90964264.html
- https://www.abendzeitung-muenchen.de/muenchen/iaa-protestcamp-eilantrag-gegen-kvr-auflagen-von-gericht-weitgehend-abgelehnt-art-754531
- https://www.stern.de/panorama/regional/eilantrag-gegen-auflagen-fuer-iaa-protestcamp-eingereicht--30716564.html
- https://www.tag24.de/muenchen/iaa-protestcamp-gericht-erlaubt-feldkueche-fuer-alle-2109918
- https://www.rtl.de/cms/eilantrag-gegen-auflagen-fuer-iaa-protestcamp-eingereicht-4826233.html

## 01.09.2021:

- https://www.sueddeutsche.de/muenchen/automesse-proteste-und-diskussionen-1.5397842
- https://www.abendzeitung-muenchen.de/muenchen/schikane-kvr-wehrt-sich-gegen-vorwuerfe-von-iaa-gegnern-art-753535

## 24.08.2021:

- https://www.sueddeutsche.de/muenchen/muenchen-klimacamp-zur-iaa-im-riemer-park-1.5390507

## 16.08.2021:

- https://www.sueddeutsche.de/muenchen/muenchen-iaa-theresienwiese-protestcamp-kommentar-1.5382551
- https://www.sueddeutsche.de/muenchen/muenchen-iaa-protest-theresienwiese-camp-1.5382549!amp?__twitter_impression=true

## 11.08.2021:

- https://www.abendzeitung-muenchen.de/muenchen/iaa-protest-in-muenchen-wohin-mit-dem-klimacamp-art-748812

## 28.07.2021:

- https://www.abendzeitung-muenchen.de/muenchen/waehrend-iaa-klimaaktivisten-planen-protestcamp-auf-theresienwiese-art-745344

## 27.07.2021:

- https://www.evangelisch.de/inhalte/188839/27-07-2021/klima-camp-statt-oktoberfest-waehrend-der-iaa-muenchen-geplant
- https://www.br.de/nachrichten/bayern/statt-oktoberfest-klima-camp-waehrend-iaa-in-muenchen-geplant,SeMaUlD

## 21.07.2021:

- https://www.sueddeutsche.de/muenchen/verkehrswende-ausgebremst-am-stachus-1.5358373
