---
title: "Presse Spiegel 2023"
description: "Alle artikel über das Mobiwende camp aus dem Jahr 2023"
---

## 04.10.2023

- https://www.hallo-muenchen.de/muenchen/mitte/muenchen-schwabing-west-freimann-mobilitaetswende-camp-foerderung-geld-mord-kapitalismus-92557863.html

## 14.09.2023

- https://www.jungewelt.de/artikel/459003.repression-am-rande-der-iaa-wer-nach-aktivismus-aussah-wurde-kontrolliert.html

## 13.09.2023

- https://www.nd-aktuell.de/artikel/1176250.polizeiproblem-protest-gegen-die-iaa-massenhaft-daten-eingesammelt.html

## 12.09.2023

- https://www.t-online.de/tv/nachrichten/id_100240256/muenchen-schlagstockeinsatz-gegen-iaa-demonstrierende.html
- https://www.fr.de/panorama/haelfte-ab-aktivismus-protest-muenchen-iaa-mobility-schwere-vorwuerfe-polizist-schlug-ohr-zur-92510749.htmlhttps://www.fr.de/panorama/haelfte-ab-aktivismus-protest-muenchen-iaa-mobility-schwere-vorwuerfe-polizist-schlug-ohr-zur-92510749.html
- https://perspektive-online.net/2023/09/muenchen-dezentrale-protestaktionen-gegen-die-iaa/
- https://www.tz.de/welt/muenchen-mercedes-benz-im-fokus-von-aktivisten-klimakrise-oder-krieg-hauptsache-profit-iaa-zr-92512837.html

## 11.09.2023

- https://www.sueddeutsche.de/muenchen/muenchen-iaa-protest-polizei-pressearbeit-behinderung-1.6216382
- https://www.abendblatt.de/wirtschaft/article239430581/Bilanz-der-IAA-Proteste-Alle-mehr-oder-weniger-zufrieden.html
- https://taz.de/Protest-gegen-Automobilausstellung-IAA/!5956556/
- https://www.sueddeutsche.de/muenchen/iaa-mobility-internationale-automobilausstellung-muenchen-1.6216305
- https://rdl.de/beitrag/vielf-ltiger-protest-gegen-klimafeindliche-motoren-und-ihre-anh-nger
- https://www.abendzeitung-muenchen.de/muenchen/so-lief-der-grosse-iaa-protest-und-klima-demo-in-muenchen-wirklich-eine-sauerei-art-926769
- https://www.telepolis.de/features/IAA-Mobility-und-Klimaproteste-wie-in-Muenchen-Welten-aufeinander-prallten-9300428.html
- https://www.abendzeitung-muenchen.de/muenchen/az-newsblog-zu-klimaprotesten-und-iaa-in-muenchen-iaa-gegner-und-ob-reiter-ziehen-bilanz-art-923877
- https://www.merkur.de/bayern/bmw-dingolfing-klimaaktivisten-sand-im-getriebe-blockieren-werkstor-92508264.html
- https://www.pnp.de/lokales/landkreis-dingolfing-landau/blockade-bei-bmw-keine-festnahme-14302259
- https://www.merkur.de/wirtschaft/bilanz-der-iaa-proteste-alle-mehr-oder-weniger-zufrieden-zr-92512843.html
- https://www.tz.de/muenchen/stadt/aktionen-iaa-muenchen-eroeffnung-klima-proteste-92501575.html
- https://www.rtl.de/cms/iaa-proteste-symbolische-hausbesetzung-demo-und-blockaden-7289f8aa-c0b3-5584-ad1e-6e7ef16e32bd.html
- https://www.aachener-zeitung.de/wirtschaft/bilanz-der-iaa-proteste-alle-mehr-oder-weniger-zufrieden_aid-97435431
- https://www.sueddeutsche.de/auto/auto-bilanz-der-iaa-proteste-alle-mehr-oder-weniger-zufrieden-dpa.urn-newsml-dpa-com-20090101-230911-99-153387

## 10.09.2023

- https://www.abendblatt.de/wirtschaft/article239426801/Weitere-Protestaktionen-zum-Abschluss-der-IAA-gestartet.html
- https://www.br.de/nachrichten/bayern/friedlicher-protest-zum-abschluss-der-iaa-in-muenchen,TpR4u7d
- https://www.merkur.de/lokales/muenchen/iaa-demo-mit-fast-3000-teilnehmern-mitten-durch-muenchen-pyrotechnik-gezuendet-92511204.html
- https://www.manager-magazin.de/unternehmen/autoindustrie/iaa-weitere-demonstrationen-und-aktionen-erwartet-a-1853aa52-6c6f-4921-94ca-958fab533d6d
- https://www.zdf.de/nachrichten/heute-sendungen/videos/protest-iaa-muenchen-klimaaktivist-video-100.html
- https://www.wiwo.de/unternehmen/automobilmesse-friedlicher-protest-zum-iaa-abschluss/29382956.html
- https://www.welt.de/newsticker/dpa_nt/infoline_nt/wirtschaft_nt/article247391916/Friedlicher-Protest-zum-IAA-Abschluss.html
- https://www.sueddeutsche.de/muenchen/iaa-muenchen-klimaproteste-newsblog-elektroautos-mobilitaetswende-camp-besucherzahl-1.6192593
- https://taz.de/Verhinderte-Proteste-gegen-die-IAA/!5956522/
- https://www.abendzeitung-muenchen.de/muenchen/endspurt-der-iaa-proteste-ziviler-ungehorsam-in-muenchen-art-926437
- https://www.tz.de/muenchen/stadt/iaa-demo-mit-fast-3000-teilnehmern-mitten-durch-muenchen-pyrotechnik-gezuendet-92511202.html
- https://www.tz.de/muenchen/stadt/hallo-muenchen/muenchen-iaa-aktivist-ohr-abgeschlagen-polizei-kritik-klima-protest-letzte-generation-blockade-92510965.html
- https://www.nd-aktuell.de/artikel/1176182.verkehrswende-protest-bei-der-iaa-der-autolobby-in-die-suppe-gespuckt.html
- https://www.telepolis.de/features/IAA-Mobility-Lang-lebe-das-Auto-9300142.html
- https://www.sueddeutsche.de/muenchen/iaa-mobility-muenchen-auto-messe-polizei-demos-1.6213300
- https://www.zeit.de/news/2023-09/10/weitere-protestaktionen-zum-abschluss-der-iaa-gestartet?utm_referrer=https%3A%2F%2Fduckduckgo.com%2F
- https://www.abendzeitung-muenchen.de/muenchen/polizei-in-muenchen-blossgestellt-wie-die-hausbesetzung-in-sendling-ablief-art-926719

## 09.09.2023

- https://www.sueddeutsche.de/panorama/iaa-proteste-demonstranten-blockieren-strasse-und-besetzen-haus-1.6210303
- https://www.faz.net/aktuell/politik/inland/iaa-protest-in-muenchen-aktivisten-blockieren-strasse-und-besetzen-haus-19162710.html
- https://www.br.de/nachrichten/bayern/gegen-die-iaa-blockaden-besetzung-und-mercedes-protest,TpMQn1X
- https://www.t-online.de/region/muenchen/id_100240262/muenchen-klimaaktivisten-besetzen-strasse-vor-altem-gebrauchtwarenhaus.html
- https://taz.de/Proteste-gegen-IAA-in-Muenchen/!5959054/
- https://www.stern.de/news/muenchen–iaa-proteste–symbolische-hausbesetzung-und-strassenblockade-33810398.html
- https://www.flz.de/article/id/ps-0f2678b8-3d80-4828-afe8-7e977ee7bffa
- https://www.fuldaerzeitung.de/politik-und-wirtschaft/iaa-proteste-symbolische-hausbesetzung-und-strassenblockade-zr-92510073.html
- https://www.schwaebische.de/regional/bayern/iaa-proteste-symbolische-hausbesetzung-demo-und-blockaden-1890493
- https://bnn.de/nachrichten/deutschland-und-welt/iaa-proteste-symbolische-hausbesetzung-und-strassenblockade
- https://www.mv-online.de/in-und-ausland/wirtschaft/iaa-proteste-symbolische-hausbesetzung-und-strassenblockade-660201.html
- https://www.azonline.de/amp/welt/wirtschaft/iaa-proteste-symbolische-hausbesetzung-und-strassenblockade-2823897

## 08.09.2023

- https://www.pnp.de/lokales/landkreis-dingolfing-landau/aktivisten-blockieren-werkstor-bei-bmw-in-dingolfing-14279858
- https://www.br.de/nachrichten/bayern/900-klimaaktivisten-gegen-iaa-im-muenchner-mobilitaetswendecamp,TpGmb77
- https://www.automobilwoche.de/nachrichten/bmw-dingolfing-klima-aktivisten-storen-produktion
- https://www.sueddeutsche.de/muenchen/muenchen-iaa-klimaprotest-praeventivhaft-letzte-generation-1.6207009
- https://www.sueddeutsche.de/bayern/auto-dingolfing-aktivisten-blockieren-werkstor-bei-bmw-in-dingolfing-dpa.urn-newsml-dpa-com-20090101-230908-99-121073
- https://www.stern.de/gesellschaft/regional/bayern/protestaktion–aktivisten-blockieren-werkstor-bei-bmw-in-dingolfing-33807984.html
- https://www.t-online.de/nachrichten/panorama/id_100239728/klimaaktivisten-blockieren-bmw-werk-in-dingolfing.html
- https://www.autohaus.de/nachrichten/autohandel/bmw-aktivisten-blockieren-werkstor-in-dingolfing-3434065
- https://taz.de/Proteste-gegen-Automesse-IAA/!5958976/
- https://www.tz.de/bayern/dingolfing-klimaaktivisten-sand-im-getriebe-blockieren-werkstor-bmw-92508267.html
- https://taz.de/IAA-in-Muenchen/!5956464/

## 07.09.2023

- https://www.zeit.de/2023/38/iaa-proteste-auto-klimaaktivismus
- https://www.br.de/nachrichten/bayern/iaa-protest-attac-tauscht-in-muenchen-werbeplakate-aus,Tp9m0xQ
- https://www.sueddeutsche.de/muenchen/muenchen-iaa-protestcamp-klimaaktivisten-luitpoldpark-nachbarn-1.6203768
- https://www.sueddeutsche.de/muenchen/muenchen-iaa-protest-attac-fahrrad-letzte-generation-1.6203971
- https://www.fr.de/politik/mobilmachen-gegen-die-iaa-in-muenchen-92502074.html
- https://www.stern.de/wirtschaft/news/aktivismus–iaa-proteste–attac-tauscht-werbeplakate-in-muenchen-aus-33802886.html
- https://taz.de/Internationale-Automobilausstellung/!5955665/
- https://radiocorax.de/tag-zwei-des-iaa-protest-camps/

## 06.09.2023

- https://www.merkur.de/lokales/muenchen/iaa-in-muenchen-geht-weiter-klima-aktivisten-kuendigen-blockade-von-zwoelf-strassen-mit-gehzeugen-an-92503217.html
- https://www.zeit.de/video/2023-09/6336630859112/iaa-klimaaktivisten-protestieren-gegen-automesse-iaa
- https://www.spiegel.de/auto/automesse-iaa-die-polarisierende-kraft-der-elektroautos-a-1c5f82be-7563-4aba-ac3d-f20609be28b4
- https://www.sueddeutsche.de/muenchen/iaa-muenchen-polizei-letzte-generation-proteste-1.6200672

## 05.09.2023

- https://www.abendzeitung-muenchen.de/muenchen/luitpoldpark-in-muenchen-ein-zeltlager-fuer-1500-protestler-gegen-die-iaa-art-925532
- https://www.sueddeutsche.de/muenchen/muenchen-iaa-protest-auto-wasser-mittlerer-ring-klimacamp-1.6194139
- https://www.sueddeutsche.de/muenchen/muenchen-iaa-protest-attac-extinction-rebellion-radtour-polizei-1.6197328
- https://www.tagesschau.de/wirtschaft/iaa-eroeffnung-100.html
- https://www.stern.de/panorama/video-klimaziele-gehen-in-rauch-auf—protest-bei-der-automesse-iaa-33798824.html
- https://www.telepolis.de/features/IAA-Mobility-Muenchen-im-Zeichen-von-Automobilismus-und-Klimaprotest-9294883.html
- https://www.stuttgarter-nachrichten.de/inhalt.protest-aktion-auf-der-iaa-aktivisten-stoeren-kanzler-so-lief-der-scholz-besuch-bei-mercedes.cec1e47e-c93e-49e3-b5fb-0c54d7903fb4.html
- https://www.br.de/nachrichten/wirtschaft/iaa-mobility-muenchen-autoshow-und-proteste,ToaO
- https://www.br.de/nachrichten/bayern/iaa-protestcamp-startet-blockaden-und-demonstrationen-geplant,ToswiG9
- https://nypost.com/2023/09/05/greenpeace-disrupts-munich-car-show-as-german-chancellor-calls-protests-irritating/
- https://www.reuters.com/technology/space/germany-launch-massive-expansion-ev-charging-network-says-scholz-2023-09-05/
- https://www.handelsblatt.com/unternehmen/industrie/klimaproteste-klimaaktivisten-stoeren-iaa-rundgang-von-olaf-scholz/29373662.html

## 04.09.2023

- https://www.br.de/nachrichten/wirtschaft/automesse-iaa-mobility-startet-in-muenchen-mit-protesten,Toob1Tx
- https://www.ardmediathek.de/video/Y3JpZDovL3N3ci5kZS9hZXgvbzE5MTY2MTc/
- https://www.sueddeutsche.de/muenchen/muenchen-letzte-generation-newsblog-iaa-blockaden-polizei-stadelheim-1.6161712
- https://www.sueddeutsche.de/wirtschaft/iaa-muenchen-proteste-aktivisten-autohersteller-1.6184922
- https://www.faz.net/aktuell/wirtschaft/auto-verkehr/iaa-in-muenchen-so-viel-protest-erntet-die-automesse-19141757.html
- https://www.zdf.de/nachrichten/panorama/automobilmesse-iaa-protest-demonstration-blockade-100.html
- https://lora924.de/2023/09/04/blockiaa-ueberblick-ueber-die-protest-gruppen/
- https://www.sueddeutsche.de/panorama/greenpeace-versenkt-autos-zu-beginn-der-iaa-1.6193028
- https://taz.de/IAA-Automesse-in-Muenchen/!5955112/
- https://www.faz.net/aktuell/politik/inland/iaa-greenpeace-versenkt-autos-zu-beginn-der-messe-19149463.html
- https://www.tagesschau.de/inland/regional/badenwuerttemberg/swr-klimaaktivisten-protestieren-gegen-iaa-100.html
- https://www.stuttgarter-nachrichten.de/inhalt.iaa-2023-in-muenchen-klimaaktivisten-setzen-mit-protest-erste-zeichen.78d6c90d-fcd7-42ad-b76c-2aa6114e5dac.html
- https://www.rnd.de/panorama/rund-um-die-iaa-drohen-massive-proteste-von-klimaaktivisten-OCE3IJTBWZMZTEQUKIX2QSCRI4.html
- https://www.merkur.de/wirtschaft/proteste-rund-um-die-iaa-was-zu-erwarten-ist-zr-92496372.html
- https://www.zdf.de/nachrichten/panorama/automobilmesse-iaa-protest-demonstration-blockade-100.html

## 29.08.2023

- https://www.sueddeutsche.de/muenchen/muenchen-iaa-protest-demonstrationen-veranstaltungen-polizei-1.6175159

## 23.08.2023

- https://taz.de/Proteste-gegen-Automesse/!5955741/
- https://www.merkur.de/lokales/muenchen/iaa-in-muenchen-klimaaktivisten-kuendigen-protest-an-92476422.html
- https://www.abendzeitung-muenchen.de/muenchen/iaa-gegner-kuendigen-proteste-gegen-die-automesse-in-muenchen-an-planen-aktionen-des-zivilen-ungehorsams-art-922782
- https://www.tz.de/muenchen/stadt/iaa-in-muenchen-klimaaktivisten-kuendigen-protest-an-92476420.html
- https://anfdeutsch.com/Oekologie/iaa-mobility-soll-wieder-blockiert-werden-38748
- https://www.tz.de/muenchen/stadt/hallo-muenchen/iaa-protest-camp-luitpoldpark-sorgen-muenchen-schaeden-theresienwiese-92481576.html

## 17.08.2023

- https://lora924.de/2023/08/17/mobilitaetswendecamp-hat-veranstaltungsort/

## 16.08.2023

- https://www.sueddeutsche.de/muenchen/muenchen-iaa-mobility-protestcamp-luitpoldpark-1.6132963
- https://www.tz.de/muenchen/stadt/hallo-muenchen/muenchen-iaa-klima-aktivisten-protest-camp-luitpoldpark-mobilitaetswende-92407820.html
- https://www.merkur.de/lokales/muenchen/muenchen-iaa-protestcamp-zieht-in-den-luitpoldpark-92463498.html
- https://www.t-online.de/region/muenchen/id_100225934/autobranche-laedt-letzte-generation-auf-iaa-ein-.html
- https://www.abendzeitung-muenchen.de/muenchen/iaa-klimacamp-kommt-in-den-luitpoldpark-in-muenchen-bezirksausschuss-chefin-protestiert-art-921385
- https://www.spiegel.de/wirtschaft/unternehmen/muenchen-autobranche-laedt-letzte-generation-zur-iaa-ein-a-78f6c9fa-9cd4-4851-b684-02240c48ed94
- https://rp-online.de/wirtschaft/messe-in-muenchen-autobranche-laedt-letzte-generation-zur-iaa-ein_aid-95812569
- https://orf.at/stories/3327746/
- https://taz.de/Autolobby-und-Letzte-Generation-auf-IAA/!5950346/

## 24.07.2023

- https://www.abendzeitung-muenchen.de/muenchen/protest-gegen-die-automesse-iaa-in-muenchen-im-september-was-die-aktivisten-planen-art-916604

## 20.07.2023

- https://lora924.de/2023/07/21/planung-fuer-ort-x-das-mobilitaetswende-camp-fuer-protestierende-gegen-die-iaa/

## 18.07.2023

- https://www.zeit.de/news/2023-07/18/gegner-der-automesse-iaa-planen-erneut-protestcamp
- https://www.sueddeutsche.de/bayern/auto-gegner-der-automesse-iaa-planen-erneut-protestcamp-dpa.urn-newsml-dpa-com-20090101-230718-99-440701
- https://www.abendzeitung-muenchen.de/muenchen/iaa-gegner-planen-erneut-protestcamp-aber-nicht-auf-der-theresienwiese-art-915205
- https://www.faz.net/agenturmeldungen/dpa/gegner-der-automesse-iaa-planen-erneut-protestcamp-19041363.html
- https://www.merkur.de/lokales/muenchen/erneut-protestcamp-zur-iaa-in-muenchen-geplant-mit-platz-fuer-ueber-1000-leute-92407870.html
- https://www.tz.de/muenchen/stadt/hallo-muenchen/muenchen-klima-aktivisten-iaa-protest-camp-polizei-mobilitaetswende-92407820.html
- https://www.t-online.de/region/muenchen/id_100209476/muenchen-gegner-der-automesse-iaa-planen-bereits-protestcamp-.html
- https://www.bild.de/regional/muenchen/muenchen-aktuell/automesse-iaa-gegner-planen-erneut-protestcamp-in-muenchen-84723794.bild.html
- https://www.n-tv.de/der_tag/Aktivisten-planen-Protestcamp-gegen-Automesse-in-Muenchen-article24268689.html
- https://www.autohaus.de/nachrichten/autohandel/automesse-iaa-gegner-planen-erneut-protestcamp-3401685
- https://www.sonntagsblatt.de/artikel/epd/wieder-klima-protest-camp-waehrend-automobil-schau-iaa-geplant
- https://www.welt.de/regionales/bayern/article246441076/Gegner-der-Automesse-IAA-planen-erneut-Protestcamp.html
- https://www.rtl.de/cms/gegner-der-automesse-iaa-planen-erneut-protestcamp-ef7bf7ef-781a-5475-9d33-c5591359f6d2.html
- https://www.stern.de/gesellschaft/regional/bayern/umwelt–gegner-der-automesse-iaa-planen-erneut-protestcamp-33659870.html
- https://www.pnp.de/nachrichten/bayern/gegner-der-automesse-iaa-planen-erneut-protestcamp-12365781
- https://www.mittelbayerische.de/nachrichten/bayern/gegner-der-automesse-iaa-planen-erneut-protestcamp-12365781
- https://www.automobilwoche.de/agenturmeldungen/gegner-der-iaa-wollen-wieder-protestcamp-einrichten
- https://www.evangelische-zeitung.de/klima-protest-camp-waehrend-automobil-schau-iaa-geplant
- https://www.automobilwoche.de/agenturmeldungen/gegner-der-iaa-wollen-wieder-protestcamp-einrichten
- https://www.radiogong.de/news/protest-camp-muenchen-iaa-auto-ausstellung-oktoberfest-theresienwiese/3352495
- https://www.freie-radios.net/123399

