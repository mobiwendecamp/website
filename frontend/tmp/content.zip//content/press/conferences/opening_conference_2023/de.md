---
title: "Auftakt Pressekonferenz 2023"
description: "Zum Auftakt der Proteste gegen die IAA fand am Montag den 04.09. um 10:00 Uhr eine Pressekonferenz mit dem Titel #blockIAA auf dem Camp statt"
date: 2023-08-04
published: true
---

Zum Auftakt der Proteste gegen die IAA fand am Montag den 04.09. um 10:00 Uhr eine Pressekonferenz mit dem Titel #blockIAA auf dem Camp statt. Eine Aufzeichnung finden Sie auf dem YouTube Kanal „Der Pilger“:

[Auftakt Pressekonferenz 2023](https://youtu.be/QSS9o3sDKcM)
