---
title: "Abschluss Pressekonferenze 2023"
description: "Fazit zum Mobilitätswende Camp 2023"
date: 2023-09-11
published: true
---

Vom 5.9. bis 10.9. fand in München zum zweiten mal die International Automobil Ausstellung statt.
Im Luitpoldpark wurde von Aktivist*innen ein Protestcamp errichtet. Dort sammelten sich Aktivist*innen aus einem breiten Spektrum um gegen die Zerstörung der Umwelt durch Kraftfahrzeuge und deren Beitrag zur Klimakatastrophe zu protestieren.
Am Tag nach dem Ende der IAA 2023 zogen Vertreter*innen verschiedener Gruppen ein Fazit zu den Protestaktionen.

[Abschluss Pressekonferenze 2023](https://youtu.be/FhvZNMDehzg)
