---
title: "Abschluss Pressekonferenze 2021"
description: "Pressekonferenz von Bündnissen gegen die IAA 2021 zu den Protesten der vergangen Tage und das Vorgehen der Polizei gegen Demonstrant*innen."
date: 2021-08-12
published: true
---
Pressekonferenz von Bündnissen gegen die IAA 2021 zu den Protesten der vergangen Tage und das Vorgehen der Polizei gegen Demonstrant*innen.
[Abschluss Pressekonferenze 2021](https://youtu.be/c9ddL-bFLNM)
