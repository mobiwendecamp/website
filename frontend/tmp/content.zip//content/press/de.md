---
title: "Presse"
description: "Alle informationen zu Pressekontakten und Pressekonferenzen"
hero_image: 'press.jpg'
---

Pressekontakt:

E-Mail: mobilitaetswende_camp_muenchen@riseup.net

Pressetelefon:

Presse Mobilitätswende Camp 2023:
