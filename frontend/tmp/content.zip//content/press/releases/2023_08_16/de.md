---
title: "Pressemitteilung vom 18. Juli 2023"
description: "IAA Protest: Aktivist*innen planen erneut ein Klima-Protest-Camp gegen die Internationale Automobil-Ausstellung in München"
date: 2023-07-18
published: true
---

## Auch in Bayern müssen die Grundrechte respektiert werden!

Die Klimaaktivist*innen des Mobilitätswende-Camps München planen nach ihrem erfolgreichen Protest-Camp 2021 erneut ein Camp gegen die Internationale Automobil-Ausstellung
(IAA) 2023 in München. Es soll vom 5. bis 10. September stattfinden und etwa 1500 Teilnehmer*innen Platz bieten. Die Veranstalter*innen rechnen für dieses Jahr mit ähnlich großen Protestaktionen wie vor zwei Jahren. Da Anfang September auf der Theresienwiese bereits mit den
Aufbauarbeiten für das Oktoberfest begonnen wird, wird das Camp dieses Mal in einen städtischen Park umziehen. Die Abstimmungen dazu mit dem Kreisverwaltungsreferat der Stadt sind
bereits in vollem Gange. "Die Zusamenarbeit mit dem Kreisverwaltungsreferat läuft sehr konstruktiv. Wir haben dieses Mal das Gefühl, dass wirklich daran gearbeitet wird, das Camp im
Sinne des Grundrechts auf Versammlungsfreiheit zu ermöglichen!", lobt Vanessa Probst vom
Camp-Organisations-Team. "Eine Zusage haben wir aber noch nicht."

Die Protestierenden fordern, dass auch die Polizei und das bayerische Innenministerium die
Grundrechte respektieren müssen und haben mit Blick auf die jüngsten Ereignisse im Zusammenhang mit den Aktivist*innen der Letzten Generation große Sorgen: "Aufgrund der Hausdurchsuchungen, Verhaftungen und Überwachung von Aktivist*innen der Letzten Generation
befürchten wir, dass das bayerische Innenministerium und die Polizei versuchen werden, das
Versammlungsrecht bei den Protesten gegen die IAA zu beschneiden", so Vanessa Probst.
"Dennoch werden wir unser Klima-Protest-Camp aufbauen und gegen die IAA auf die Straße
gehen. Wir lassen uns nicht einschüchtern!"

"Für uns leistet die IAA keinen Beitrag zu einer Mobilitätswende. Mobilitätswende bedeutet
für uns nicht, dass Konzerne weiterhin Profite mit dem Verkauf von Autos - egal ob mit Verbrennungs- oder Elektromotor - machen, sondern ein Ende des Autoverkehrs, wie wir ihn kennen", erklärt Vanessa Probst. "Eine klimagerechte Mobilitätswende bedeutet, dass wir eine
Form der Mobilität brauchen, die nicht auf der Ausbeutung ehemals kolonialisierter Länder für
immer mehr Autos beruht. Mit unserem Camp wollen wir für eine andere Form der Mobilität
werben und denen eine Bühne bieten, die Ideen für eine echte klimagerechte Mobilitätswende
haben. Dass man in München Autokonzernen, die Menschenrechte mit Füßen treten, ein zweites Mal zentrale öffentliche Plätze für ihre klimaschädliche Propaganda zur Verfügung stellt,
verurteilen wir aufs Schärfste!"

Pressekontakt: mobilitaetswende_camp_muenchen@riseup.net
Folgende Organisationen und Bündnisse unterstützen die Forderung nach einer zentralen
Campfläche in einem städtischen Park:

- IAA Demoorganisation
- OKNB - Ohne Kerosin Nach Bayern
- Sand im Getriebe
- No Future for IAA
- Smash IAA
- Kochkollektiv Knoblauchfahne
- Fridays for Future München
- Jugendorganisation BUND Naturschutz
