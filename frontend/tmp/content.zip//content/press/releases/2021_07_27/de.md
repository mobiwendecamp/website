---
title: "Pressemitteilung vom 01. September 2021"
description: "IAA-Protest: Klimacamp auf der Theresienwiese Platzzusage nach drei Monaten zäher Verhandlungen - aber unverhältnismäßige Auflagen angekündigt"
date: 2021-08-01
published: true
---

Das Mobilitätswende-Camp München wird seine Zelte vom 7. bis 12. September auf
der Theresienwiese aufschlagen. Das ist der Stand nach drei Monaten zäher
Verhandlungen der IAA-Kritiker*innen mit der Stadt München.

Drei Tage vor dem Aufbau fehlt aber immer noch der Auflagenbescheid und damit
echte Planungssicherheit. Zudem hat das Kreisverwaltungsreferat (KVR) in einem
Kooperationsgespräch am Montag Auflagen angekündigt, die aus Sicht der CampOrganisator*innen vollkommen unverhältnismäßig sind. So will das KVR nicht
erlauben, dass Teilnehmende durch eine spendenfinanzierte „Küche für alle“
versorgt werden. Außerdem sollen keine Zirkuszelte aufgebaut werden. Die
"Bequemlichkeit" der Teilnehmer*innen dürfe nicht im Vordergrund stehen, begründet
die Behörde ihre Entscheidung. "Das ist absurd. Das Übernachten auf der steinigen
Theresienwiese ist ohnehin alles andere als bequem. Es ist völlig unverständlich,
warum die Stadt uns jetzt noch mehr Steine in den Weg legt und unseren
notwendigen zivilgesellschaftlichen Protest weiter massiv behindert. Das schmeckt
nach Schikane ", sagt Vanessa Probst vom Orga-Team des Camps.
Aus Sicht der Aktivist*innen ist die "Küche für alle" essenzieller Bestandteil des
Klimacamps, da sie eine konsumfreie und nachhaltige Ernährung für die
Teilnehmer*innen ermöglicht. Die Zirkuszelte werden für eine corona-konforme
Durchführung der Workshops benötigt.

Die Camp-Organisator*innen wollen die Beschneidung ihrer Versammlungsfreiheit
nicht akzeptieren und sind bereit, dies auch notfalls vor Gericht durchzusetzen, falls
auf dem Verhandlungsweg keine Lösungen gefunden werden. Als besonders
ärgerlich empfinden sie es, dass ihnen die Einschränkungen durch die Behörden erst
jetzt mitgeteilt worden sind, obwohl sie das Camp bereits vor drei Monaten mit den
bekannten Inhalten angemeldet hatten. In den vergangenen Monaten hatte das KVR
eine Zusage immer wieder verweigert und behauptet, auf der 42 Hektar großen
Theresienwiese gebe es keinen Platz für das vier Hektar große Klimacamp, weil dort
am 11. September etwa zwei Stunden lang auch die Kundgebung des Anti-IAAProtestbündnisses #aussteigen stattfinden wird.
Um die Infrastruktur für ein funktionierendes Camp bereitzustellen, mussten im
Vorfeld schon Verträge für Strom, Wasser, Abfallentsorgung, Zelte, (Dixi)klos und
Technik abgeschlossen sowie die benötigten Lebensmittel eingekauft werden - und
das ohne Bescheid. "Die Stadt München hat uns jegliche Planungssicherheit
vorenthalten. Die Kosten belaufen sich mittlerweile auf mehrere zehntausend Euro,
die wir durch mühevolles Crowdfunding einsammeln müssen", berichtet Vanessa
Probst. "Trotzdem steht eins fest: Am Freitag beginnen wir, das Camp aufzubauen!"
Klimagerechtigkeit, Rohstoffabbau und Flucht sind zentrale Themen im Camp

Das Mobilitätswende-Camp soll den Protest gegen die IAA zum Ausdruck bringen
und zugleich auf die Klimakatastrophe hinweisen. „Mit unserer Zeltstadt mitten in
München wollen wir zeigen, was es bedeutet, wenn Überschwemmungen oder
Brände unser Zuhause zerstören. Zugleich wollen wir eine Woche lang eine
klimagerechte Gesellschaft vorleben - mit Basisdemokratie, Workshops in
Zirkuszelten und einer selbst organsierten, veganen Küche", sagt Frederik Müller
vom Orga-Team. "Und im Gegensatz zur IAA Mobility, die weiterhin eine reine
Verkaufsveranstaltung für immer mehr Autos ist, wollen wir echte Antworten darauf
finden, wie wir zu einer Mobilität mit sehr viel weniger Autos kommen." Inhaltlich
werden sich die Camp-Teilnehmer*innen vor allem mit den Themen
Klimagerechtigkeit, Rohstoffabbau in Ländern des Südens - auch für Elektroautos -
sowie Flucht als Folge des Klimawandels befassen.
Zum Schutz vor Ansteckungen mit Corona haben die Organisator*innen des
Klimacamps ein umfangreiches Hygienekonzept entwickelt. Neben Maskenpflicht
und Abstandsregeln soll für Camp-Teilnehmende die 3G-Regel gelten.

-------------------------------------------------------------------------------------------------

Folgende Organisationen und Bündnisse unterstützen die Forderung nach einer
zentralen Campfläche in München:
– #noIAA
– KonTra IAA – Kongress für transformative Mobilität
– Sand im Getriebe
– Smash IAA
– No Future for IAA
– VolxKüche München
– Soliküche Augsburg
– Fridays for Future München
– Jugendorganisation BUND Naturschutz
– IAA Demo und Sternfahrt
Pressekontakt
Mobilitaetswende Camp Muenchen
