---
title: "Pressemitteilung vom 27. Juli 2021"
description: "IAA: Aktivist*innen planen Klima-Camp auf Theresienwiese"
date: 2021-07-27
published: true
---

Stadt München muss auch Protestierenden Raum geben, nicht nur der Autoindustrie
Klimaaktivist*innen aus München planen ein Klima-Protest-Camp während der Internationalen
Automobilausstellung (IAA) in München. Das Mobilitätswende-Camp München soll vom 7. bis 13. September
etwa 1500 Teilnehmer*innen der IAA-Proteste Platz bieten. Geeignete Orte sind aus Sicht der CampOrganisator*innen die Theresienwiese oder der Hermann-von-Siemens-Sportpark. Gespräche dazu laufen mit
dem Kreisverwaltungsreferat der Stadt, eine Zusage gibt es noch nicht.

„Viele klimaaktivistische Gruppen haben angekündigt, gegen die IAA in München zu protestieren, die in ihren
Augen allein dem Greenwashing der Autoindustrie dient. Als Mobilitätswende-Camp wollen wir ihnen eine
Übernachtungsmöglichkeit, Verpflegung und ein breites Bildungsprogramm bieten. Das Camp soll einen
entscheidenden Anlaufpunkt der Klimagerechtigkeitsbewegung bilden, die sich für eine echte Mobilitätswende
engagiert, statt sich mit einer ‚Antriebswende‘ zufriedenzugeben“, sagte Michael Jäger vom Camp-Bündnis.
„Wir fordern die Stadt München auf, auch den Protestierenden angemessen Raum zu geben, nachdem sie der
IAA sämtliche öffentliche Flächen in der Innenstadt vom Odeonsplatz bis zum Marienplatz zur Verfügung
gestellt hat. Das Camp soll allen Menschen ermöglichen, ihre Grundrechte auf freie Meinungsäußerung und
Versammlungsfreiheit wahrnehmen zu können."

Auf Infrastruktur wie Schlafplätze und Küche zu verzichten, ist aus Sicht der Organisator*innen keine Option,
denn in einer der drei teuersten Städte Europas können sich die Protestierenden kaum ein Hotel oder
Vollverpflegung leisten. Zudem wird mit dem Camp ein Ort entstehen, der an sich schon ein Ausdruck des
Protestes gegen die IAA und das auto-zentrierte Verkehrssystem und damit auch Symbol eines gesellschaftlichen
Gegenentwurfes ist. Da sich das Camp auf die Säulen der verfassungsmäßig geschützten Grundrechte stützt,
muss die Stadt es ermöglichen, die für die Teilnahme an Kundgebungen erforderliche Infrastruktur
bereitzustellen. Das haben viele Gerichtsurteile bei den Klimacamps im Rheinland oder bei Protestcamps in
anderen deutschen Großstädten bestätigt.

Das Kreisverwaltungsreferat der Stadt München dagegen verhält sich in jüngster Zeit eher als Verhinderin statt
Partnerin zivilgesellschaftlicher Initiativen. So wurde die Standzeit eines Informationscontainers zum Thema
Mobilität, den der Bund Naturschutz auf dem Stachus aufstellen wollte, so stark beschränkt, dass er abgesagt
werden musste. „Wir fordern die Stadt und das Kreisverwaltungsreferat auf, kooperativ und konstruktiv ein
zentrales Protest- und Bildungscamp zu ermöglichen. Andernfalls erwägen wir, uns unser Verständnis von
Demokratie und Versammlungsrecht auf dem Klageweg bestätigen zu lassen. Wir werden für unseren Raum in
der Stadt kämpfen!“

Um das Risiko einer Corona-Infektion gering zu halten, bereiten die Aktivist*innen ein ausgeklügeltes
Hygienekonzept nach dem Vorbild anderer Camps vor, die damit gute Erfahrungen gemacht haben.

Folgende Organisationen und Bündnisse unterstützen die Forderung nach einer zentralen Campfläche in
München:
- #noIAA
- KonTra IAA - Kongress für transformative Mobilität
- Sand im Getriebe
- Smash IAA
- No Future for IAA
- VolxKüche München
- Soliküche Augsburg
- Fridays for Future München
- Jugendorganisation BUND Naturschutz
  Pressekontakt:
  mobilitaetswende_camp_muenchen@riseup.net
