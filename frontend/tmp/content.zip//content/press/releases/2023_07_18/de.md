---
title: "PRESSEMITTEILUNG vom 16. August 2023"
description: "IAA-Protest: Standort gefunden. Mobilitätswende-Camp München findet im Luitpoldpark statt."
date: 2023-08-16
published: true
---
Nach langem Hin und Her wurde uns nun ein Standort für das Mobilitätswende-Camp vom
Kreisverwaltungsreferat zugesichert.

Die Ehrenamtlichen des Mobilitätswende-Camps planen nach ihrem erfolgreichen Protest 2021
erneut ein Bildungs- und Protestcamp gegen die Internationale Automobil-Ausstellung (IAA) 2023
in München. Es soll vom 5. bis 10. September etwa 1500 Teilnehmer*innen Platz bieten.
„Für eine bessere Planbarkeit wollten wir die Standortfrage für unser Camp frühzeitig klären. Wir
haben bereits vor Monaten das Gespräch mit dem Kreisverwaltungsreferat gesucht, wodurch wir
konstruktiv kooperieren konnten“, resümiert Pressesprecherin Vanessa Probst vom CampOrganisations-Team.
Zunächst war der Bavariapark als Camp-Standort vom KVR festgelegt worden. Diese Zusage
wurde allerdings zurückgezogen, aufgrund zuvor unbekannter Sonderauflagen für die Nutzung des
Parks. „Das hat uns schwer an die Situation vor 2 Jahren erinnert, als wir aufgrund schikanierender
Auflagen immer wieder am Aufbau unseres Mobilitätswende-Camps gehindert wurden“, fügt
Probst hinzu.

„Stattdessen wird den Autokonzernen zum wiederholten Male der rote Teppich ausgerollt. Die Stadt
München und unsere öffentlichen Plätze werden als Tribüne für die Profitinteressen der
Automobilindustrie missbraucht“, erklärt Vanessa Probst und sagt: „Dass es so mühsam ist, einen
geeigneten Platz für unseren demokratischen Protest zu finden, ist dem Ausverkauf unserer
Versammlungsorte an die IAA geschuldet. Das sagt viel über die Prioritäten der Staatsregierung und
der Landeshauptstadt aus.“
Das Mobilitätswende-Camp wird ein diverses Alternativprogramm zur PS-Show und deren
Greenwashing bieten. Aktivist*innen, Referent*innen und Interessierte finden so Wege aus der
fossilen Autofalle und zu einer Mobilität, die uns Menschen nützt statt den Aktionär*innen der
Autoindustrie.

„Mit dem Luitpoldpark haben wir einen zentralen Platz für unser Camp gefunden. Wir werden in
der Innenstadt, direkt an den Ausstellungsorten, unseren Aktivismus für eine klimagerechte
Mobilitätswende der IAA entgegensetzen“, freut sich Vanessa Probst auf den September.
Vom Luitpoldpark aus wird auch die Großdemonstration am 10.09. „#BlockIAA! Für wen wird hier
eigentlich Politik gemacht?!“ um 11 Uhr starten.

Bei Rückfragen melden Sie sich gerne bei Vanessa Probst unter der Telefonnummer:
+491639329761
oder schreiben Sie uns: mobilitaetswende_camp_muenchen@riseup.net

Folgende Organisationen und Bündnisse unterstützen die Pressemitteilung:

- #blockIAA Demoorganisation
- OKNB - Ohne Kerosin Nach Bayern
- Sand im Getriebe
- No Future for IAA
- Smash IAA
- Kochkollektiv Knoblauchfahne
- Fridays for Future München
- Attac Deutschland
