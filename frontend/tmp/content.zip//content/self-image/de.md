---
title: "Selbstverständnis"
toc_enabled: true
---

> Selbstverständnis der Camp Orga 2024/25: Beschlossen ohne Bedenken auf dem Plenum am 17.12.2024

## Haltung - Wer sind wir?

Das Mobilitätswendecamp ist Teil der globalen Klimagerechtigkeitsbewegung. Das Mobilitätswendecamp München ist eine Versammlung, die sich als antifaschistisch versteht. Es dient zur Vernetzung aller teilnehmenden Gruppen und Einzelpersonen, die sich gegen die IAA engagieren, Inhalte und Programmpunkte auf dem Camp durchführen und besuchen oder eigene Proteste vorbereiten wollen.

Wir, die Orga des Camps, sind eine offene, von Klimagerechtigkeit bewegte Gruppe, und bringen Erfahrungen aus unterschiedlichen Gruppen, Strömungen und Camps zusammen. Die organisierenden Menschen und Gruppen bekennen sich in ihrer Zusammenarbeit und in der Ausrichtung des Camps zu diesem Selbstverständnis, insbesondere beim Einstieg von neuen Menschen in die Camp-Orga.

### Zielsetzung

Unser übergeordnetes Ziel ist eine globale klimagerechte und soziale Mobilitätswende, das wir nur erreichen können, wenn wir unser Zusammenleben an den Bedürfnissen aller Menschen und der Natur statt den Profiten weniger Konzerneigentümer\*innen ausrichten.

Wir stehen ein für

- eine sozial gerechte und klimaverträgliche Mobilitätswende
- gutes Leben für alle in einer klimagerechten, inklusiven und friedlichen Zukunft
- eine Welt ohne Kapitalismus und Ausbeutung

#### Gegen IAA und Autokapitalismus

Die Internationale Automobilausstellung (IAA) ist nicht nur Symbol des kapitalistischen Wirtschaftssystems, sondern auch konkrete Werbe-, Organisations- und Vermarktungsplattform der Unternehmen und ihrer superreichen Eigentümer\*innen. In ihrer Verantwortung liegen Ausbeutung, Unterdrückung und Klimazerstörung für die eigene Profitmaximierung. Daher wollen wir gemeinsam durch vielfältige Proteste und Bildungsangebote über die große Problematik der IAA aufklären. Die Solidarität innerhalb dieser Vielfalt sehen wir dabei als unsere Stärke und lassen uns nicht spalten.

Wir engagieren uns gegen die Automobilausstellung, weil …

- die Beschlagnahme des öffentlichen Raums durch die IAA aufhören muss,
- ihre Selbstdarstellung als „Mobilitätsausstellung“ reines Greenwashing ist,,
- eine wirklich sinnvolle Mobilitätswende nur möglich ist, wenn wir uns von den Bedürfnissen aller Menschen und der Natur leiten lassen.

#### Gegen Faschismus

In einer faschistischen Welt kann es keine gerechte Mobilitätswende oder irgendeine Gerechtigkeit geben. Deshalb positionieren wir uns klar antifaschistisch und stellen uns entschieden gegen die AfD und alle anderen Akteur\*innen, ob in Parlamenten oder außerhalb, die aktiv die Lebensrealität unzähliger Menschen verschlechtern, bedrohen oder zerstören wollen.

### Weitere Themen

Auf dem Camp wollen wir über Themen wie die Kilmakatastrophe, Rassismus, Kolonialismus, Queerfeindlichkeit, Faschismus, Ableismus, patriarchale Systeme, ... informieren und versuchen einen Beitrag zur Bekämpfung dieser zu leisten. Gemeinsam wollen wir Machtstrukturen transparent machen und abbauen.

### Beteiligung

Wir wollen mit allen am Camp Beteiligten zusammen leben, uns kennenlernen und gemeinsam Visionen für ein besseres und nachhaltigeres Leben für alle diskutieren und ausprobieren. Ein Camp wie dieses kann nur gelingen, wenn alle Teilnehmenden sich solidarisch beteiligen können und auch beteiligen. Grundsätzlich verstehen wir rassismuskritische, antikoloniale, queerfeministische und antifaschistische Praxis als notwendige Voraussetzung für eine nachhaltige Mobilitätswende und Zukunft.

### Umgang mit Diskriminierung

Wir wollen uns in wertschätzender und lernender Haltung damit auseinandersetzen, dass auch das Camp kein Safe Space für alle sein kann. Trotzdem und deshalb möchten wir gemeinsam erforschen, wie wir das Camp in mutiger Kritik und Handlung zugänglicher machen können.

In Auseinandersetzung mit strukturellen Diskriminierungen werden wir sowohl in der Vorbereitung als auch in der Durchführung kritisch begleitet und unterstützt. Wir sind uns bewusst, dass verschiedene Diskriminierungsformen sich überlagern und gegenseitig verschärfen können.

Außerdem bieten wir eine Awareness-Struktur an, welche im \[Awareness-Konzept\](...) weiter erläutert wird.

### Unsere Haltung zu internationalen Konflikten

#### Im Hinblick auf internationale Konflikte gilt für uns:

Bezüglich einer Verkürzung auf einzelne Aspekte sowie bezüglich legitimer Kritik, soll es im Rahmen des Mobiwendecamps der folgende Anspruch sein: Als vom Konflikt nicht direkt betroffene Personen (in Bezug auf Trauma und Krieg) werden wir keine starken Meinungen äußern und kein weiteres Öl ins Feuer schwelender geopolitischer Konflikte gießen. Stimmen der betroffenen Gruppen müssen sich, wenn sie Mitglied der Camporga sind, bewusst sein, dass ein wertschätzender Umgang auch mit politischen Gegner\*innen notwendig bleibt, solange dieser erwidert wird. Wenn dieser Umgang ausbleibt, können betreffende Personen vom Camp ausgeschlossen werden.

Wir setzen uns als Camporga für einen wohlwollenden und verständnisvollen Umgang auf dem Camp ein, mit dem sich alle Menschen so sicher wie möglich fühlen können. Die Komplexität der historischen Zusammenhänge erfordert Sensibilität aller am Diskurs Beteiligter. Eindimensionale Vereinfachungen, Verallgemeinerungen und Pauschalverurteilungen verbieten sich.

#### 1. Israel & Palästina

Wir erkennen die Rechte aller Menschen auf ein Leben in Frieden und Freiheit gleichermaßen an Wir verurteilen jegliche menschenverachtenden Handlungen und Haltungen, ohne diese gleichsetzen oder gegeneinander aufwiegen zu wollen.

Als mehrheitlich weiße Gruppe üben wir uns darin, gleichzeitiges Leiden verschiedener Gruppen zu sehen und politische Differenzen auszuhalten.

Zur Beschreibung der aktuellen Verhältnisse betrachten wir die Entwicklung der Einschätzung unabhängiger internationaler Institutionen. Zur Beurteilung mutmaßlicher Fälle von Antisemitismus im Camp verwenden wir die Jerusalemer Erklärung Antisemitismus: https://www.jerusalemdeclaration.org/wp-content/uploads/JDA-German.pdf

#### 2. Ukraine & Russland

Wir sehen die russische Regierung als klaren Aggressor des Ukrainekrieges. Wir sind solidarisch mit den Menschen, die von ihren Regierungen in den Angriffskrieg und die Verteidigung gezogen werden oder Gewalt erfahren.

#### 3. Kurdistan

Die Unterdrückung der kurdischen Bevölkerung lehnen wir ab. Darüber hinaus zeigen wir uns solidarisch mit den Kurd\*innen die sich gegen die Aggression stellen.

#### 4. Zu wenig beachtete geopolitische Konflikte

Wir sind uns im Klaren darüber, dass es global viele aktive und schwelende Konflikte gibt, zu denen wir uns in ihrer Vielzahl hier nicht äußern können. Am Ende stehen wir auf der Seite der Menschen, die unterdrückt werden.

## Voraussetzungen für die Mitarbeit in der Camporga

Wir wollen uns untereinander eine offene, lernende und wertschätzende Haltung entgegenbringen.

Wir erwarten

- die klare positive Haltung zur rassismuskritischen, queerfeministischen, klassistischen und ableistischen Kämpfen und deren Intersektionalität (Verschränkung und gegenseitige Verstärkung von Diskriminierung).
- die klare Haltung, zur Abschaffung von patriarchalen Systemen. Insbesondere auch die Bereitschaft zur regelmäßiger Übernahme von Carearbeit zu gerechten Anteilen.
- Bewusstsein über Kampfbegriffe der neuen Rechten (z.B. "Genderdebatte" oder "Lügenpresse").
- sicheres Wissen über Allyship.
- Und Bewusstsein in Bezug auf weitere Diskriminierungsformen (siehe Awareness-Konzept: LINK).
- Beziehungsweise die Bereitschaft zur Auseinandersetzung mit den oben genannten Punkten.

Wir bieten regelmäßig Onboardings an, bei denen neu dazustoßende Menschen in die Arbeitsweise der Orga eingeführt werden. Die Teilnahme daran ist verpflichtend.

### Unvereinbarkeit

Die Mitarbeit in der Camporga setzt obige Haltung voraus.

Explizit unvereinbar sind für uns:

- Verschwörungsideologien (z.B. Weltherrschaft durch jüdische Beteiligung, Reptiloiden,  Chemtrails, Corona-"Leugnende", Leugnung der Klimakrise oder andere unwissenschaftliche Behauptungen.)
- Mitglied bei einer menschenverachtenden und/oder aktiv an Diskriminierung beteiligten Gruppe.

### Organisatorische Struktur

Wir sind in Arbeitsgruppen (AGs) organisiert und entscheiden im Plenum gemeinsam im Konsent (Abfrage von Widerständen, ohne Vetomöglichkeit).

### Programm

Das Camp bietet eine Plattform für politische und gesellschaftskritische Bildung und Austausch.

- Das Bildungsprogramm wird dezentral organisiert und von Gruppen unterschiedlicher Ausrichtungen kuratiert.
- Den  Rahmen bildet ein diverses Programm mit Künstler\*innen und Workshops,  sowie unterhaltende und bildende Programmpunkte, die einen Austausch  zwischen Münchner Bürger\*innen, sowie zwischen Menschen verschiedener Hintergründe ermöglichen.
- Parteiwerbung oder Parteiveranstaltungen jeglicher Art sind ausgeschlossen.

### Spenden

Zur Deckung der Kosten des Camps sind wir auf Spendengelder angewiesen. Wir versuchen, diesen Betrag durch Fördergelder und sparsame Ausgaben möglichst niedrig zu halten. Jede Person kann dabei selbst entscheiden ob und wieviel Geld sie für das Camp spenden kann und möchte. Der Spendenstand wird auf dem Camp transparent gemacht. Der Besuch des Camps ist ohne Beitrag möglich.

Wir nehmen keine Spenden von der Autolobby, Großkonzernen und Parteien an.
