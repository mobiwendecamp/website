---
title: "Programm"
description: "Der Programmkalender für das Camp 2025"
---


### Hier werden dann alle Infos zu unserem Programm, Workshops und Acts veröffentlicht werden. 
