---
title: "Die Planungen fürs Mobilitätswende Camp 2025 haben begonnen"
description: "Du willst mit uns für einen gerechte Mobilitätswende kämpfen und mithelfen das camp zu Organisieren. Hier erfährst du wie."
date: 2024-09-16
published: true
---
