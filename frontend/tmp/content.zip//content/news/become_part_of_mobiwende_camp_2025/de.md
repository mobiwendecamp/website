---
title: "Komm in die Orga"
description: "Du willst mit uns für einen gerechte Mobilitätswende kämpfen und mithelfen das camp zu Organisieren. Hier erfährst du wie."
date: 2024-11-16
published: true
---
