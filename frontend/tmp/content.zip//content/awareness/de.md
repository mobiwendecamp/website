---
title: "Awareness-Konzept"
description: "In unserem Awarness-Konzept Bla"
toc_enabled: true
hero_image: "hero_6.jpg"
---


> Disclaimer
> Das Awareness-Konzept kann sich ständig verändern. Wir freuen uns über euer Feedback und eure Kritik. Das Konzept
> wurde von der Awareness-AG geschrieben und ist aus Zeitgründen nicht im Konsens mit der gesamten Camp-Orga beschlossen
> worden.

## Kurzfassung

Wir wollen das Mobilitätswendecamp München als einen „safeR“ Space aufbauen, also einen Ort, an dem es deutlich weniger
Diskriminierung, mehr Reflektion und ein harmonischeres Miteinander gibt, als es derzeit in unserer Gesellschaft die
Norm ist. Dafür fordern wir von Allen eine lernende und offene Haltung ein. Wir begegnen uns mit dem Wissen, dass wir
auf struktureller Ebene alle unterschiedlich auch grenzüberschreitend sind, und teilen das Ziel weniger Verletzungen zu
verursachen.

Wir ermutigen dich vor allem, Kritik zu üben. Kritik sollte grundsätzlich ernst genommen werden. So können wir uns
mutiger der Angst vor abwehrenden Reaktionen auf die eigene Kritik stellen. Wer Kritik äußert, hat in der Regel das
Bedürfnis nach kollektiver Besserung, und das kommt uns allen zugute. Kritik kann also auch ein Akt der Wertschätzung
sein, insbesondere wenn wir dabei Betroffenen zuhören.

Es gibt ein FLINTA*-Zelt, ein BIPoC-Zelt und ein Zelt für Menschen mit Behinderung, zu denen nur die jeweiligen Gruppen
Zutritt haben. Es ist zur demokratischen Selbstverwaltung überlassen.

Außerdem gibt es ein BIPoC-Camp, ein FLINTA*-Camp und ein Queer Camp, idealerweise mit Überschneidung. Die Campflächen
sind ausgeschildert. Bitte halte dich fern, wenn du nicht zu den entsprechenden Gruppen gehörst. Wenn du dir eine
geschütztere Campfläche wünschst, die nicht öffentlich ausgeschildert ist, komm zum Awareness-Zelt.

Awareness ist die Verantwortung aller Teilnehmenden am Camp. Ergänzend gibt es während des Camps eine
Awareness-Struktur, die sich sowohl in einer Sensibilisierungsrolle als auch als Ansprechpartner*in bei
grenzüberschreitendem, übergriffigem und diskriminierendem Verhalten versteht.

Wenn du davon betroffen bist oder Du aus anderen Gründen Redebedarf hast, kannst Du Dich jederzeit an Ansprechpersonen
der Awareness-Struktur wenden – du erkennst uns an der lila Weste.

Telefonisch erreichst Du uns unter *0152 12415641*, außerdem sind wir im Awarenesszelt ansprechbar.

Das Recht darüber zu entscheiden, wann die eigenen Grenzen überschritten sind, liegt bei der davon betroffenen Person (
Definitionsmacht). Das Erlebte wird vom Awareness-Team nicht in Frage gestellt.

Jeder Impuls zu uns zu kommen ist wichtig und darf befolgt werden. Melde Dich bitte lieber einmal zu viel als einmal zu
wenig!

Hör auf deinen Körper und deine emotionale und psychische Verfassung, überbeanspruche und überanstrenge dich nicht und
gib auf dich selbst und deine Bedürfnisse acht. Gib dir selbst regelmäßig Auszeiten und schätze deine Pausen wert;
trinke genug Wasser und versuche, genug und gesund zu essen.

Solltest du Drogen wie Alkohol oder Tabak konsumieren bist du dafür verantwortlich, dass die Grenzen deiner Mitmenschen
nicht überschritten werden.

Es gibt drogenarme Bereiche auf dem Camp, in denen nicht konsumiert werden soll – kein Trinken und kein Rauchen: Das
sind grundsätzlich die Campingplätze, wo es deine zeltenden Nachbar:innen stören könnte, in den Programmzelten und
SafeR-spaces und im Essbereich.

Entsorge bitte grundsätzlich deine Kippenstummel in (Hand-)Aschenbechern und im Müll. Bitte halte das Gelände sauber und
nimm Rücksicht. (E-)Zigaretten sind hier keine Ausnahme.

Sei dir bitte im Klaren: ohne Alkohol bleibt uns am nächsten Tag mehr Energie für die Dinge für die wir einstehen.
Außerdem trägt der Konsum von Alkohol häufig zu nächtlichen Lärmbelästigungen und Übergriffen bei. Das gesamte Camp ist
als politische Versammlung angemeldet und alleine deshalb solltest du immer einen klaren Kopf behalten um jederzeit
verantwortungsbewusst für dich und für Andere handeln zu können!

Am Infopoint findest du eine Feedback-Box, in der du der Camporga Feedback hinterlassen kannst. Wir leeren diese Box
jeden Tag und versuchen, das Feedback direkt umzusetzen.

In unserem ausführlichen Awareness-Konzept findest du weitere Informationen zu Diskriminierungsformen wie Rassismus,
Ableismus, Sexismus, Klassismus, Antisemitismus und weiteren. Außerdem sind gängige Begriffe zu Awareness und
Machtstrukturen definiert. Lies gerne das Awareness-Konzept, um deinen Reflexionsprozess zu beginnen oder fortzusetzen.

Wir freuen uns auch über einen aktiven Austausch über die Inhalte des Awareness-Konzepts. Lasst uns gerne
Änderungswünsche und Diskussionsbeiträge zukommen.

## Einleitung

Das Mobilitätswendecamp München soll ein Ort sein an dem sich alle wohl fühlen können. Dafür ist ein achtsamer,
diskriminierungssensibler und solidarischer Umgang miteinander die Grundlage.

Bitte beachte: Es ist uns bewusst, dass wir keinen „Safe“ Space anbieten können. Die gesellschaftliche Realität ist,
dass Rassismus, Sexismus, Klassismus, Ableismus und weitere Formen von Diskriminierung in uns allen verinnerlicht sind.
Dazu tragen auch strukturelle Voraussetzungen bei. Beispielsweise besteht das Kernorgateam der Awareness AG und des
Mobilitätswendecamps bisher hauptsächlich aus weißen Menschen.

Als Orga-Team der Awareness-Struktur versuchen wir Formen von Diskriminierung zu reflektieren, sowohl die
Diskriminierung, die wir verinnerlicht haben, als auch Machtausübung in unseren Strukturen.

Wir wollen das Mobilitätswendecamp München als einen „safeR“ Space aufzubauen, also einen Ort, an dem es deutlich
weniger Diskriminierung, mehr Reflektion und ein harmonischeres Miteinander aller gibt, als es derzeit in unserer
Gesellschaft die Norm ist. Dafür fordern wir von Allen eine lernende und offene Haltung ein. Wir begegnen uns mit dem
Wissen, dass wir auf struktureller Ebene alle unterschiedlich auch grenzüberschreitend sind, und teilen das Ziel weniger
Verletzungen zu verursachen.

## Awareness-Konzept

Der Begriff „Awareness” kommt aus dem Englischen „to be aware“ und bedeutet (im weiteren Sinne):

„sich bewusst sein, sich informieren, für gewisse Probleme sensibilisiert sein“.

Wir leben in einer Gesellschaft, die von ungleichen Machtverhältnissen geprägt ist. Menschen werden aufgrund bestimmter
Merkmale bevorteilt (Privilegierung) und benachteiligt (Diskriminierung) – ob absichtlich oder unbewusst ausgeübt.

Kein Mensch ist vorurteilsfrei und diskriminierungsfrei im Umgang mit anderen. Um trotzdem solidarisch miteinander
dieses Camp organisieren und erleben zu können, wünschen wir uns, dass wir uns alle bewusst reflektieren und
informieren. Verletzendes und grenzüberschreitendes Verhalten, wie z.B. sexistische, rassistische, queer-,
transfeindliche, ableistische, antisemitische, klassistische oder vergleichbare Übergriffe tolerieren wir auf dem Camp
nicht.

Wir verstehen Awareness als herrschaftskritisches Handeln und als Antirepressionsstruktur (ergänzend und unterstützend
zu den Strukturen Out-Of-Action, Sanis und EA (Ermittlungsausschuss) – siehe unten)

Awareness ist die Verantwortung aller Teilnehmenden am Camp. Ergänzend gibt es während des Camps eine
Awareness-Struktur, die sich sowohl in einer Sensibilisierungsrolle als auch als Ansprechpartner*in bei
grenzüberschreitendem, übergriffigem und diskriminierendem Verhalten versteht.

Wenn du davon betroffen bist oder Du aus anderen Gründen Redebedarf hast, kannst Du Dich jederzeit an Ansprechpersonen
der Awareness-Struktur wenden – du erkennst uns an der lila Weste.

Telefonisch erreichst Du uns unter 0152 12415641, außerdem sind wir im Awarenesszelt ansprechbar.

Auch hier wollen wir noch einmal darauf hinweisen, dass der Awareness-Raum kein „Safe“ Space sein kann und dass damit
auch die Arbeit der Awareness-Ansprechpersonen nicht frei von Diskriminerung, rassistischen Strukturen und Denkmustern
sowie internalisierten Machtgefügen sein kann.

Wann Menschen ihre Grenzen verletzt sehen und welches Verhalten als Gewalt erfahren wird, kann sehr unterschiedlich
sein. Das Recht darüber zu entscheiden, wann etwas als gewaltausübend und grenzüberschreitend gilt, liegt bei der davon
betroffenen Person (Definitionsmacht).

Das Erlebte wird von uns nicht in Frage gestellt.

Jeder Impuls zu uns zu kommen ist wichtig und darf befolgt werden. Melde Dich bitte lieber einmal zu viel als einmal zu
wenig!

Die Rolle der Awareness-Struktur sehen wir als empathischen und parteilichen Beistand. Es geht darum, das Gefühl von
Ohnmacht und Ausgeliefertsein zu überwinden und, dass persönliche Grenzen – egal, wo sie liegen – völlig okay sind.
Dabei bleibt alles, was du uns anvertraust, unter uns: Wir gehen vertraulich mit dem um, was wir erfahren und besprechen
Situationen nur anonymisiert. Im Mittelpunkt steht die konkrete Unterstützung der betroffenen Person entsprechend ihrer
Bedürfnisse. Wenn du möchtest, suchen wir gemeinsam nach einem Umgang, mit dem du dich wohler fühlen kannst. Es wird
nichts ohne deine eindeutige Zustimmung passieren.

Wenn Du problematisches Verhalten in deinem Umfeld mitbekommst, kannst und sollst Du Dich gerne melden.

Neben „offiziellen“ Awareness-Strukturen, sind wir alle auch immer mit dafür verantwortlich, dass das Camp ein
„saferR“-Space und diskriminierungssensibler Raum für alle Aktivistis ist:

*Awareness ist Gruppenaufgabe!*

Verlasse Dich also nicht nur darauf, dass die Arbeit vom Awareness-Team erledigt wird, sondern traue dich, deine
Mitmenschen zu unterstützen. Arbeite aktiv mit und hinterfrage Deine Machtposition, Dein Auftreten und Verhalten, auch
wenn Du noch nicht drauf angesprochen wurdest.

Die Awareness-Koordination ist ebenfalls für Barrierearmut auf dem Camp verantwortlich.

### Selfawareness
Hör auf deinen Körper und deine emotionale und psychische Verfassung, überbeanspruche und überanstrenge dich nicht und
gib auf dich selbst und deine Bedürfnisse acht. Gib dir selbst regelmäßig Auszeiten und schätze deine Pausen wert;
trinke genug Wasser und versuche, genug und gesund zu essen. Alle Ansprechpersonen des Awareness-Teams sollten ihre
Grenzen selber kennen und mitteilen. Bei Unsicherheiten sollte sich prinzipiell die Zeit und der Raum genommen werden,
mit anderen Personen darüber zu reden. Im Zweifelsfall fühle dich dazu ermutigt, dich bedingungslos aus unangenehmen
Situationen herauszunehmen.

### Was das Awareness-Team nicht macht
Das Awareness-Team sind keine Mediator*innen (Streitschlichtende). Wenn du dich an die Awareness-Menschen wendest, weil
du dich in einem Streit ungerecht behandelt oder diskriminiert fühlst, ergreifen sie Partei für dich. Sie wollen
erreichen, dass es dir besser geht. Dadurch verlieren sie ihre Neutralität, weshalb sie nicht schlichten können.

Wir setzen uns dafür ein, dass es allen auf dem Camp gut geht, aber das können wir nicht erreichen. Repressionen,
Konflikte und Diskriminierungen werden trotzdem passieren.

Falls sich zu wenig Menschen in die Awareness-Schichten einträgt, kann es sein, dass es zwischendurch kein
Awareness-Team gibt.

Die Awareness-Struktur ersetzt keine Therapie. Wir bemühen uns, die Menschen in den Awareness-Teams vorher grundlegend
für ihre Aufgabe auszubilden. Nicht alle, die Awareness-Schichten übernehmen, erhalten diese Ausbildung. Wenn du das
Gefühl hast, die Personen in der aktuellen Awareness-Schicht machen deine Situation noch schlimmer, frage lieber
woanders um Hilfe.

Für einen psychologischen oder psychiatrischen Notfall fehlt dem Awareness-Team die entsprechende Ausbildung: Bei Bedarf
kontaktieren sie die Sanitäter*innen.

### Rassismuskritische Praxis
Auch linke Orgas sind rassistisch!

Die Camp-Orga hat im letzten Jahr gelernt:
– dass es nicht ausreicht für Gerechtigkeit einzutreten und gegen Rassismus zu sein.
– dass es nicht ausreicht sich als Antirassist:in zu bezeichnen.

Wir sind nicht antirassistisch, aber wir wollen rassismuskritisch sein.

#### Warum?
Die Rassismuskritik geht im Gegensatz zu Antirassismus ausdrücklich davon aus, dass Rassismus als gesellschaftliche
Normalität existiert:
Alle Menschen werden durch Kategorisierungen, Zuschreibungen und Diskriminierungen positioniert.
Die Camp-Orga, als größtenteils weiße Gruppe, gesteht sich ein, dass sie Rassismus reproduziert.
Es ist nicht ausreichend sich gegen Rassismus zu positionieren.
Wir sind “die Guten“ und die Nazis „die Bösen“: Diese Moralisierung ist nicht hilfreich – sie blendet aus, dass
Rassismus ein strukturelles Problem ist. Aktiv gegen Rassismus können wir nur innerhalb des rassistischen Systems sein
und darin haben wir die Verantwortung rassistische Diskriminierungen abzubauen. Dabei dürfen wir nicht die Schuldfrage
mit der Frage nach der Verantwortung verwechseln.

#### Sei dir deiner Position bewusst!
Die eigene Positionierung und die eigenen Privilegien sind bei allen Handlungen zu reflektieren, damit nicht
rassistische Strukturen gestützt und reproduziert werden.
In der Rassismuskritik achten wir darauf, nicht viktimisierend (Zuschreibung einer Opferrolle) zu kommunizieren,
aufzutreten oder zu handeln: Dies stellt eine zusätzliche Form der Unterdrückung dar.
Wenn du mehr zu dem Thema wissen möchtest und dich reflektieren möchtest, bitte recherchiere den Begriff „white
saviorism“.

Die Praxis der Rassismuskritik ist selbstreflexiv, komplex, oft widersprüchlich und grundsätzlich kein abschließbarer
Prozess.

#### Was ist rassistisch?
Noah Sow („Deutschland Schwarz Weiß“) sagte in der TAZ: „Rassistisch ist, wenn das Ergebnis zur strukturellen
Benachteiligung führt. Einfacher verständlich wird es, wenn wir fragen: „Wem wird dadurch geholfen/wer wird dadurch
bevorzugt?“ Darauf müsste dann meiner Meinung nach folgen: „Wie kann ich mithelfen, das auszugleichen?“

#### Und jetzt?!
Wir fordern alle Besucher:innen des Camps auf, sich zu dem Thema zu bilden: Bitte reflektiere deine eigene Position und
hinterfrage sie kritisch.
Die offene, mutige und konsequente Begegnung mit dem
Thema ist unser aller Verantwortung!

Wahrscheinlich wird das Camp mehrheitlich von weiß positionierten Menschen besucht werden. Allein das sorgt schon dafür,
dass die Campfläche kein Safe Space für BIPoC ist. Für dich als BIPoC wird es daher BIPoC-only-Orte auf dem Camp geben.

Es gibt BIPoC-only Campflächen, wo du dein Zelt aufstellen kannst. Das BIPoC-Camp ist nicht öffentlich gekennzeichnet.
Am Infopoint und im Awareness-Zelt erfährst du, wo diese Fläche ist.
Außerdem wird es ein BIPoC-only-Zelt geben. Das Zelt ist allen BIPoC zur freien Gestaltung und demokratischen
Selbstverwaltung überlassen. Wir stellen eine Liste zur Verfügung, über die BIPoC das Zelt für einen bestimmten Zeitraum
buchen können. Diese Liste hat Gültigkeit, solange es keine Widerstände dagegen gibt.

Wichtige Punkte für die rassismuskritische Praxis:

- Das N-Wort, das Z-Wort und andere abwertende Fremdbezeichnungen haben auf dem Camp nichts zu suchen weil sie sehr
verletzend wirken können.
- BIPoC und Personen ohne deutsche Staatsbürgerschaft sind stärker von Repression durch die Polizei gefährdet, bitte
verhalte dich unbedingt solidarisch.
- Versuche, auch über Sprachbarrieren hinweg miteinander zu kommunizieren.
- Wenn es einen Rassismusvorwurf gibt, ist dieser erstmal ernst zu nehmen, auch wenn weiß Positionierte ihn nicht oder
nicht auf Anhieb verstehen. Ein natürlicher Mechanismus ist, ihn zu verharmlosen oder andere Gründe für den Vorwurf zu
finden. Als weißer Mensch bitte sei dir dessen bewusst, akzeptiere den Vorwurf und überlege, weshalb es vielleicht doch
rassistisch sein könnte.
- Wenn du rassistische Äußerungen und Handlungen mitbekommst, übe wohlwollend und bestimmt Kritik, wenn sich das sicher
für dich anfühlt. Wenn nicht, wende dich ans Awareness-Team.
- Tausche dich mit Anderen über Rassismuserfahrungen und den Umgang mit Rassismen aus! An die weiß Positionierten: Achte
darauf, dass sich diese Gespräche nicht (nur) um dich drehen. Wenn BIPoC anwesend sind, sei extra sensibel, wie du dich
ausdrückst, aber scheue nicht den Austausch!

### An alle weiß Positionierten:
Es ist wichtig, klare Kante gegen Rassismus zu zeigen. Das bedeutet auch, auf die Suche nach den eigenen Rassismen zu
gehen und einen Umgang damit zu finden. Dafür ist es extrem hilfreich, Texte zu lesen, Podcasts zu hören oder Filme zu
sehen. Für das Camp erstellen wir auch ein Infoplakat mit ein paar Basisinformationen zu Rassismus. Informiere dich zum
Beispiel über die Geschichte des Kolonialismus und über neokoloniale Ausbeutungsverhältnisse sowie über die
Widerstandskämpfe indigener Gemeinschaften, die Geschichte von Migration und die aktuelle Situation von Migrant*innen.
Nicht zuletzt spielt auch die Automobilindustrie eine üble Rolle in diesen Zusammenhängen. Es gibt sehr viel Material
wie Texte, Bilder und Musik von rassifizierten Menschen, die tolle Analysen enthalten und spannende Geschichten
erzählen, aber leider – aufgrund von Rassismus – nicht so bekannt sind. Es lohnt sich, explizit danach zu suchen.

Die Auseinandersetzung mit der eigenen Machtposition ist eine Sache der Solidarität. Ja, es ist unbequem und
anstrengend, aber Rassismuserfahrungen von BIPoC sind noch viel unbequemer und anstrengender. Damit BIPoC und weiß
Positionierte Seite an Seite für eine gerechte Mobilität eintreten können, liegt es in der Verantwortung weißer
Menschen, in diesen Prozess der Auseinandersetzung zu gehen. Wir verstehen ihn als lebenslangen Lernprozess, bei dem
garantiert Fehler gemacht werden. Wichtig ist, dass du bereit bist, aus diesen Fehlern zu lernen. Daher ermutigen wir
dich, gegenseitig ehrliches Feedback zu geben, wenn etwas schief gelaufen ist, und dieses Feedback ernst zu nehmen.

### Unsere Haltung zu white Locks
Wir üben und fordern Wertschätzung und Respekt für die Geschichte von Kultur und
Widerstand:
So erwarten wir von allen weißen Menschen, insbesondere wenn sie Locks tragen, eine kritische Auseinandersetzung mit
dieser Geschichte und der eigenen Entscheidung Locks zu tragen oder nicht.
Dass viele weiße Klimaaktivist*innen auf Klimacamps und in Aktionen mit Locks rumlaufen, wurde von BIPoC mehrfach
öffentlich als einer der Gründe genannt, warum viele sich in Räumen der Klimagerechtigkeitsbewegung in Deutschland
nicht wohl fühlen können.
Die Gründe dafür kannst du am Besten in
aller Ruhe nachlesen oder nachhören:

Wir empfinden es nicht als hilfreich oder angemessen, wenn weiße Menschen zu dem Thema sagen „Schneide
deine Locks ab, wir dulden hier keinen Rassismus“. Wir fordern stattdessen dazu auf, das Thema
rassismuskritisch zu bearbeiten:
Wenn du als weiße Person andere Menschen kritisierst:
Sei dir deiner Position bewusst!
Alle, besonders weiße Menschen reproduzieren Rassismus, weil wir in einem rassistischen System
sozialisiert wurden.
Wir haben damit angefangen, uns mit dem Thema zu beschäftigen und kein Mensch kann von sich behaupten, den Prozess
abgeschlossen zu haben. Also kritisiere rassistisches Verhalten Anderer, aber vergiss nicht, dass auch du nicht frei von
Rassismus
bist.
Wenn du den Impuls verspürst, eine von dir als weiß
gelesene Person auf deren Locks anzusprechen, hinterfrage, ob du gerade für dich oder für andere Menschen sprichst.
Am Infopoint stellen wir eine Ausleihkiste für Tücher zum Bedecken von Locks bereit – mit dem Wunsch Verantwortung für
sich und andere zu übernehmen.

#### Kurze Geschichte von Locks
Als Ausdruck tiefer Spiritualität und Abkehr von allem Weltlichen (inklusive Kämmen und Bürsten) entstammen Locks sowohl
dem afrikanischen, jamaikanischen (Rastafari) als auch dem indischen (Sadhus)
Raum.
Erst zur Zeit der Sklaverei erhielten sie
durch die unzähligen gefangenen und versklavten Personen aus Indien und Afrika Einzug in die USA, wo sie später von der
Schwarzen Bürgerrechts- und Black Power- Bewegung der 1950er und 1960er Jahre
aufgegriffen worden sind. Gemeinsam mit dem Afro-Look wurden sie
zum Symbol des Widerstandes gegen Marginalisierung, Imperialismus und weiße
Schönheitsnormen.

### Ableismuskritische Praxis
Viele Aspekte des Lebens werden nicht für Menschen mit Behinderungen mitgedacht, weil sie für viele Menschen ohne
Behinderungen nicht sichtbar sind. Gleichzeitig erfahren Menschen mit Behinderungen übergriffiges Verhalten, indem ihnen
Selbstständigkeit abgesprochen wird. Wenn du den Impuls verspürst einer Person ungefragt zu helfen, weil Du glaubst sie
schafft es nicht alleine, überlege vorher woher der Impuls kommt so zu denken. Du kannst den Menschen deine Hilfe
anbieten, um sie in ihrer Selbstbestimmung zu unterstützen. Achte dabei bitte darauf, dass du nicht bevormundend
handelst oder sprichst. Einige Behinderungen sind auch nicht direkt sichtbar, aber genauso einschränkend und ernst
zunehmen.

### Awareness für Gehörlose Deafhood und Taube Menschen
#### In Räumlichkeit des DeafSpace:
Es wird einen Deaf Space auf dem Camp geben. Der DeafSpace ist ein SaferSpace für taube Menschen als auch ein
BraverSpace für hörende Menschen. An diesem Ort wird in Gebärdensprache kommuniziert, denn die Gebärdensprache ist die
Sprache der tauben Menschen. Deswegen herrscht im DeafSpace grundsätzlich eine lautsprachliche Stille, um die
Gebärdensprachkultur der tauben Menschen zu respektieren. Ein diverses Programm vermittelt Inhalte bzw. Erfahrungen aus
tauber Perspektive.
Um überhaupt Aufklärungsarbeit leisten zu können, wird daher während den Vorträgen/Workshops etc. mit Lautsprache
verdolmetscht, um Bewusstsein bei den Hörenden zu bilden.
Der DeafSpace möchte dem hegemonialen Lautsprachmacht entgegenwirken und daher innerhalb der DeafSpace Bewusstseinarbeit
leisten, um die Machtgefälle auszugleichen. Ein wichtiger Teil der Bewusstseinsarbeit ist, sich der Visualität bewusst
zu werden, weil sie der Kanal zu den tauben Menschen ist. Deshalb wollen wir tauben Menschen alle hörenden Beteiligten,
wobei ihre Muttersprache die Lautsprache ist, dazu ermutigen im Rahmen der BraverSpace sich visuell zu verständigen.
Startet der Hörende lautsprachlich ein Gespräch, eine Diskussion oder einfach einen Austausch starten mit einem anderem
Hörenden innerhalb der DeafSpace [grundsätzlich eigentlich auch überall], ohne dabei die tauben Menschen zu
berücksichtigen,findet eine Diskriminierung statt und ist daher in der DeafSpace-Sphäre nicht erwünscht,
denn taube Menschen sollen bzw. wollen auch involviert sein solange ein Gespräch stattfindet bzw. kann mitbekommen, um
was es denn geht.
Wünscht eine Person eine Kontaktaufnahme, kann sie gerne auf visuellem Wege versuchen wie bspw. mittels
visuell-gestischem, über Flipchart/Handy oder mit Papier und Stift. Kreativität ist immer cool. 🙂
Selbstverständlich kann gerne Lautsprach- und Gebärdensprachdolmetscher_innen oder Kommunikationsassistenzen
herangezogen werden. Insbesondere sollten sie herangezogen werden für wichtige oder intensive Gespräche, wie ein
Austausch zu einen bestimmten Thema oder für ein Netzwerksarbeit.
Wollen hörende Personen sich innerhalb der DeafSpace in Kontakt treten, bitten wir sie darum, sich auf dem visuellen Weg
zu verständigen. Wir bitten übrigens allen, sich zu besinnen innerhalb der DeafSpace-Rahmen:
Was bedeutet es für uns allen in Hinsicht zur Kommunikation?
Wie sieht die Kommunikation aus zwischen
– einem Tauben und einem Tauben
– einem Hörenden und einem Hörenden
– schlussendlich:
zwischen einem Tauben und einem Hörenden?

Zur Klarstellung:
Der Deaf Space lädt auch alle Hörenden ein, sich ohne Lautsprache zu verständigen. Der Deaf Space soll ein Ort der
lautsprachlichen Stille sein. Ein Missachten dieses Wunsches kann je nach Situation auch als unangebrachtes Verhalten im
Deaf-Space verstanden werden, und wird zur Sprache gebracht werden. Wir wünschen uns einen solidarischen Umgang
innerhalb (und selbstverständlich auch außerhalb) des Raumes.

#### Im Räumlichkeit anderer Zelte bzw. auf dem Camp:
Für die Zugänglichkeit von lautsprachlichem Programm in DGS arbeitet ein Dolmetschenden-Team für Gebärdensprache und
Lautsprache. Für das tägliche Camp-Plenum ist zwecks Transparenz der Organisierung eine Verdolmetschung gesetzt.
Für die Verdolmetschung anderer gebärdensprachlichen als auch lautsprachlichen Angebote melde dich gerne vorab bei
awareness_noiaa@riseup.net oder komm vorher zum Deaf-Space auf dem Camp. Dort im DeafSpace wird je nach Präsenz tauber
Menschen und ihrer Interessen ermittelt und jeweils je nach Kapazität ein Dolmetschteam entsprechend zugeteilt.
(weitere Ergänzung von Matthias) Auf dem Camp werden Dolmetscher_innen und Kommunikationsassistenzen mit einer Farbweste
erkennbar sein, so dass sie bei Bedarf schnell auffindbar sind. Informationen aller Art, die über den Lautsprecher
bekanntgegeben werden, werden auf Bildschirme o.Ä., die neben dem Lautsprecher stehen als auch an gut sichtbaren Stellen
stehen, bekanntgegeben. Die Bildschirme sollten bei Bekanntgabe mit Effekte „laut sein“, damit taube Menschen sie in der
Sichtfläche noch wahrnehmen können. [Blaulicht kommt natürlich nicht in Frage. ;)]
Um auch tauben Menschen Zugang zu den Awareness-Strukturen zu ermöglichen, wird es am 4. und 5. September eine
Awareness-Schulung in DGS und deutscher Lautsprache geben. Durch ein Grundverständnis in DGS und insbesondere durch
taube Awareness-Teams soll eine Sprachbarriere abgebaut werden.

#### Was ist Audismus?
(Abgekürzt entnommen aus https://nicht-stumm.de/was-ist-audismus)

„Wie beim Ableismus ist Audismus eine diskriminierende Haltung, die ähnlich wie Rassismus und Sexismus eine bestimmte
Art zu leben oder zu sein als Standard voraussetzt. Was beim Rassismus der „weiße“ Mensch ist und beim Ableismus der
nicht (oder noch nicht) behinderte Körper ist, ist beim Audismus das „normale“ Hören, also die Fähigkeit, Informationen
rein akustisch wahrzunehmen.„
(…)
Einzelpersonen können sich ebenso quasi selbst audistisch diskriminieren: Etwa indem sie glauben, dass bestimmte Jobs
für sie nicht geeignet sind und sie deshalb einen solchen Lebensweg nicht anstreben. Die Diskriminierung in der
Community behindert wahrscheinlich am meisten: So werden an Gehörlosenschulen die besser lautsprechenden Schwerhörigen
oft gegenüber gehörlosen Erstsprachler*innen bevorzugt, bekommen bessere Noten, machen leichter das Abitur – und
nebenher wird das audistische Denken bei den Individuen verfestigt. Dabei hakt es vor allem an der Unfähigkeit der
Lehrer*innen, Gebärdensprachen zu sprechen, was auch seinen Ursprung in der Ausbildung hat: Bisher ist es zur
Qualifikation als Gehörlosenpädagog*in nicht vorgeschrieben, die Sprache der Schüler*innen zu sprechen!
Wie beim Rassismus das „white privilege“, der Weißheitsvorteil, oder beim Sexismus das „male privilege“, der
Männlichkeitsvorteil gibt es auch im Audismus das „hearing privilege“, den Hörvorteil. Diesen haben alle inne, die
besser akustisch kommunizieren können, ob es nun schwerhörige, hörende oder gehörlose Menschen sind. Im Idealfall setzen
sie ihr Privileg aber für die Gebärdensprachcommunity ein: Etwa Dolmetscher*innen, die ehrenamtlich dolmetschen, ohne
sich dabei selber in den Vordergrund zu drängen.“

### Awareness für Sehbehinderte

Noch in Bearbeitung

### Awareness für Menschen mit psychischen Erkrankungen

Oftmals erfahren Menschen mit psychischen Erkrankungen Diskriminierungen, in dem ihnen zum Beispiel die Selbständigkeit
und oder die Entscheidungsfähigkeit abgesprochen wird. Auch berichten Betroffene, dass mit ihnen gesprochen wird, wie
mit einem Kind. Diese Beispiele und weitere Formen von Diskriminierung psychisch Erkrankter wollen und werden wir nicht
dulden. Es gibt ein weites Spektrum an psychischen Erkrankungen, die ganz unterschiedliche Symptome und Verhaltensweisen
zeigen können und als diese berücksichtigt werden müssen. Denke daran, dass die betroffene Person selbst weiß, was in
einer „unawaren“ Situation am Besten hilft und gehe auf die Hilfswünsche der betroffenen Person ein. So kann sinnvoll
und diskriminierungssensibel geholfen werden.

Es wird ein Zelt geben, in dem separater Raum für Menschen mit Behinderung ist. Wenn du davon betroffen bist kannst du
dich zum Beispiel hierhin zurückziehen, wenn du Ruhe brauchst, einen Katheter wechseln musst oder dich ungestört mit
deiner Assistenz waschen möchtest.

### Queerfeministische Praxis
Dominierendes Verhalten, das anderen Menschen den Raum nimmt, sei es in Schichten, in Workshops oder im sonstigen
Campleben, soll keinen Platz bei uns auf dem Camp haben.

In unserer patriarchalen Gesellschaft geht dieses Verhalten im Allgemeinen häufiger und stärker von cis-Männern aus.

Wir möchten zusammen daran arbeiten, dass „Macker“-Gehabe reflektiert wird, und ermutigen einen offenen Umgang damit.
Auch für cis-Männer kann die Reflexion der eigenen Unterdrückungsmuster befreiend sein. Wir helfen einander aktiv, um
gegen das Patriarchat in uns anzukämpfen.

Wir können die Anrede, also das Pronomen, einer Person nicht ansehen oder -hören. Frage einfach nach! Für ein
wertschätzendes Miteinander, lasst uns auch bemühen und gegenseitig daran erinnern, das richtige Pronomen zu verwenden.

Lasst uns in Aktionen und Gesprächen gemeinsam reflektieren, wer welche Rollen und wie viel Platz einnimmt. Mit dieser
Reflexion wollen und können wir eine geschlechtergerechte Verteilung der Gesprächsanteile und Zeiträume erreichen. Auch
über patriarchale Kommunikations- und Verhaltensmuster wie z.B. „mansplaining“ wollen wir uns informieren, reflektieren
und austauschen, um sie dann nicht zu reproduzieren.

Da es Menschen mit gewölbter Brust nicht einfach möglich ist, sich im öffentlichen Raum oben ohne zu zeigen, bitten wir
alle Menschen, sich solidarisch zu zeigen und eine Art von Oberteil zu tragen – solange das Recht auf „Oben Ohne für
alle“ noch nicht erreicht ist! Kinder sind von dieser Regelung ausgenommen.

Menschen mit Kindern finden weiter unten ein Konzept zur Kinderbetreuung. Bitte nimm Rücksicht auf Menschen, die
Verantwortung für Kinder haben und deshalb nicht überall dabei sein können, Plena unterbrechen müssen und generell
schneller müde sind.

Es gibt FLINTA*-only Campflächen, wo du dein Zelt aufstellen kannst. Das FLINTA*-Camp ist nicht öffentlich
gekennzeichnet. Du kannst du Info welche Fläche es ist und wo sich befindet am Infopoint oder im Awareness erfragen.

Da das FLINTA*-Camp nicht unbedingt ein Safe Space für queere Menschen ist, gibt es nach dem gleichen Prinzip zwei
Campflächen für queere Menschen. Wenn es von der Fläche her möglich ist, wollen wir das FLINTA*-Camp, das Queer-Camp und
das BIPoC-Camp überschneiden lassen, sodass sich Personen bei denen sich diese Identitäten überschneiden, nicht für
einen Teil ihrer Identität entscheiden müssen.

Es gibt außerdem ein FLINTA*-only Zelt. Das Zelt ist allen FLINTA* zur freien Gestaltung und demokratischen
Selbstverwaltung überlassen. Wir stellen eine Liste zur Verfügung, über die FLINTA* das Zelt für einen bestimmten
Zeitraum buchen können. Diese Liste hat Gültigkeit, solange es keine Widerstände dagegen gibt.

### Klassismus
Klassismus ist die Diskriminierung aufgrund von Klasse oder sozialer Herkunft. Damit sind zum Beispiel Beruf, Gehalt,
Vermögen, Bildungsgrad, Dialekt, Vorlieben und Hobbies gemeint. All das sind Aspekte, die unsere Wertschätzung
füreinander und unseren Umgang miteinander nicht beeinflussen sollten.

Damit alle unabhängig von ihrer finanziellen Situation am Camp mitwirken können, ist die Teilnahme spendenbasiert. Wenn
du es dir nicht leisten kannst, viel zu spenden, ist das okay, lass es dir von niemandem ausreden. Wenn du mehr geben
kannst, dann tu das bitte, damit das Camp seine Kosten decken kann. Zum Abbau von Machtstrukturen zählt auch die
materielle Umverteilung – lasst uns damit direkt beginnen!

Die Themen auf dem Mobilitätswendecamp werden gerne in akademischer Sprache geführt mit Begriffen, die nur einem
elitären Kreis von Menschen geläufig sind. Bitte versuche, eine möglichst wenig akademische Sprache zu verwenden. Trau
dich, nachzufragen, wenn du ein Wort nicht kennst. Die Verantwortung für klare Kommunikation liegt bei denen, die das
Wort verwenden, nicht bei denen, die es nicht verstehen.

### Antisemitismus
„Antisemitismus ist eine bestimmte Wahrnehmung von Jüd*innen, die sich als Hass gegenüber Jüd*innen ausdrücken kann. Der
Antisemitismus richtet sich in Wort oder Tat gegen jüdische oder nichtjüdische Einzelpersonen und/oder deren Eigentum
sowie gegen jüdische Gemeindeinstitutionen oder religiöse Einrichtungen.“

In Deutschland haben wir aufgrund der Shoah eine besondere Verantwortung, uns mit Antisemitismus zu beschäftigen und ihn
zu bekämpfen. „Darüber hinaus kann auch der Staat Israel, der dabei als jüdisches Kollektiv verstanden wird, Ziel
solcher Angriffe sein.“

Wir wollen daher zwischen antisemitischer Israelkritik und legitimer Kritik an israelischer Politik differenzieren, wie
wir sie auch an der Politik anderer Staaten üben würden.

Teilweise
aus https://www.antisemitismusbeauftragter.de/Webs/BAS/DE/bekaempfung-antisemitismus/ihra-definition/ihra-definition-node.html

### Ageismus/Adultismus
Ageismus kommt vom englischen „age“, was „Alter“ bedeutet – Adultismus ist eine Herleitung des englischen Worts „adult“
für Erwachsene. Die Begriffe benennen die Benachteiligung oder Ungleichbehandlung einer Person aufgrund des Alters, das
ihnen zugeschrieben wird. Es gibt zahlreiche Vorurteile und Stereotype gegenüber älteren oder jüngeren Menschen.

Setze dich mit diesen auseinander und denke darüber nach, wie ältere oder jüngere Menschen in unserer Gesellschaft
strukturell positioniert werden.

### Neurodiversität
Neurodiversität ist die Idee, dass es „normal“ ist, dass Menschen ein Gehirn haben, das „anders“ funktioniert als die
medizinische oder gesellschaftliche Norm. Neurodivergenz ist der Begriff für Menschen, deren Gehirne auf eine oder
mehrere Arten anders funktionieren, als das, was als „normal“ oder „typisch“ nach gesellschaftlichen Normen angesehen
wird. Neurotypisch ist ein beschreibender Begriff, der sich auf jemanden bezieht, dessen Gehirnfunktionen,
Verhaltensweisen und Verarbeitung als „standard“ oder „typisch“ nach gesellschaftlichen Normen
gelten. (https://rebellisches.org/awarenesskonzept/)

Es soll einen reizarmen Raum geben, um sich aus dem oft sehr reizüberfluteten Camp Leben zurückzuziehen.

### Lookismus
Lookismus kommt vom englischen „look“, was „Aussehen“ bedeutet. Es bezeichnet die Abwertung aufgrund des Aussehens.
Achte darauf, dass du allen Menschen gleich viel Aufmerksamkeit, Respekt und Glaubwürdigkeit schenkst wie norm-schönen
Menschen. Ein Beispiel für Lookismus ist, wenn Menschen fälschlicherweise aufgrund ihres Aussehens für Zivil-Polizist*
innen gehalten werden.

### Kinder
Kinder sind auf dem Camp genauso willkommen wie Erwachsene. Es gibt ein Konzept zur Kinderbetreuung, falls Kindern
langweilig wird. Sie sind aber auch herzlich eingeladen, beim ErwachsenenProgramm mitzumachen. Habe bitte Verständnis,
wenn es nicht extra für Kinder konzipiert ist. Als erwachsener Mensch versuche bitte die Perspektiven von Kindern
miteinzubeziehen. Auch wenn sie meist kleiner sind als du, könnt ihr euch auf Augenhöhe begegnen. Wenn du dich durch
Kinder gestört fühlst, überlege weshalb die Kinder gerade störend wirken und ob sie vielleicht etwas brauchen. Du kannst
mit Kindern genauso klar kommunizieren wie mit Erwachsenen und ihnen gegenüber deine Bedürfnisse auf wertschätzende Art
und Weise äußern.

### Intersektionalität
Viele Menschen sind gleichzeitig von verschiedenen Diskriminierungskategorien betroffen. Awarenessarbeit sollte daher
intersektional gedacht werden. Wir versuchen die sich unterscheidenden Erfahrungen durch ein möglichst diverses
Awareness-Team einzubeziehen.

### Gesprächskultur
Wir möchten einen Raum schaffen, in dem wir uns gegenseitig respektieren und aufeinander eingehen. Aufeinander eingehen
ist mehr als auf die sich ausdrückende Person zu achten: Spür auch in dich hinein, woher kommt der Impuls dich selbst
auszudrücken, was möchtest du ausdrücken und warum?

### Braver Spaces
Wir wollen nicht nur einen Safer Space schaffen, in dem Menschen sich sicherer fühlen, sondern auch einen Braver Space,
in dem Menschen sich mutiger fühlen. Wir ermutigen dich vor allem, Kritik zu üben. In einem Braver Space gilt, dass
Kritik grundsätzlich ernst genommen wird, damit wir uns mutiger der Angst vor abwertenden Reaktionen oder abwehrenden
Reaktionen auf die eigene Kritik stellen. Wer Kritik äußert, hat in der Regel das Bedürfnis nach kollektiver Besserung,
und das kommt uns allen zugute. Kritik kann also auch ein Akt der Wertschätzung sein. Wenn du (mit-)kritisiert wurdest,
bedanke dich, nimm dir Zeit darüber nachzudenken und bei Bedarf kannst du anschließend auch die Kritik kritisieren.

Mit einer lernenden und offenen Haltung für Kritik wollen wir uns begegnen. Wir teilen die Perspektive, dass wir auf
struktureller Ebene alle unterschiedlich auch grenzüberschreitend sind. Wir teilen das Ziel weniger Verletzungen zu
verursachen.

### Laufender Feedback-Prozess
Am Infopoint findet ihr eine Feedback-Box, in die ihr der Camporga Feedback hinterlassen könnt. Wir leeren diese Box
jeden Tag und versuchen, das Feedback direkt umzusetzen. Hilf gerne mit, indem du uns früh genug deine Kritik zukommen
lässt.

### Awareness-Zelt / Awareness-Infopoint
Wenn Du Unterstützung vom Awareness-Team brauchst, komme gerne zum Awareness-Zelt – folge den Schildern oder orientiere
dich am Lageplan des Camps.

Wenn Du im Awareness-Zelt keinen Menschen antriffst, bitte ruf uns an unter 0152 12415641. Es kann sein, dass wir nicht
24/7 im Zelt präsent sein können.

Da der Bereich für Notfälle frei sein sollte, ist er nicht zum ‚Chillen’, sondern für die Arbeit mit Hilfesuchenden
gedacht.

## Andere Orte bereitgestellt vom Awareness-Team
– BIPoC-SafeR-Space, ein Zelt zur Selbstverwaltung durch BIPoC

– FLINTA*-SafeR-Space, ein Zelt zur Selbstverwaltung durch FLINTA*

– Reizarmes Zelt auf dem Camp

– Campflächen für BIPoC, Queers und FLINTA* (nicht öffentlich gekennzeichnet – Info gibts am Infopoint, im
Awareness-Zelt und in den beiden SafeR-Spaces oben)

## Umgang mit Verstößen gegen das Awareness Konzept
Sowohl auf individueller als auch auf struktureller Ebene wünschen wir uns weniger diskriminierendes Verhalten. Weil es
so tief verankert ist, benötigen wir einen Lernraum dafür, wie wir verletzendes Verhalten vermeiden. Verletzende
Handlungen können sowohl von der betroffenen Person, als auch von der grenzüberschreitenden Person bemerkt werden.
Beides kann mit Scham verbunden sein. In beiden Fällen kann das Awareness-Team zur Unterstützung hinzugezogen werden.
Wir wünschen uns einen solidarischen mutigen Raum, dieses grenzüberschreitende Verhalten nicht stehen zu lassen.

Für einen sicheren Raum im Umgang mit verletzenden Verhalten erwarten wir eine Bereitschaft zur Reflektion und zum
aktiven Handeln von allen auf dem Camp anwesenden Menschen.

Reflektion bedeutet hier für uns, dass alle Menschen, insbesondere wenn du darauf angesprochen wirst, auch akzeptieren,
dass grenzüberschreitendes Verhalten in uns allen steckt. Wenn du eine (potentiell grenzüberschreitende) Person auf das
Verhalten ansprichst, wie möchtest du, dass die Person reagiert? Wir erwarten auch ohne Verständnis für die Perspektive
der betroffenen Person, Mitgefühl für die Verletzung durch das eigene Verhalten. Uns ist wichtig, dass der Umgang
miteinander nicht von Verurteilung und wertender Einmischung geprägt wird – siehe auch der Absatz „Braver Space“.

## Wann und wie werden Personen ausgeschlossen?
Es kann passieren, dass sich betroffene Menschen ausgeschlossen fühlen, weil grenzüberschreitende Personen weiter auf
dem Camp geduldet werden. Der Ausschluss passiert dann dadurch, dass sie sich nicht mehr sicher/wohl fühlen. In solchen
Fällen positioniert sich das Awareness-Team hinter betroffenen Personen und nimmt die Wünsche und Forderungen von
Betroffenen auf.

Das Awareness-Team wünscht sich, dass Ausschluss eine Option ist – sieht dies allerdings als allerletzte Instanz. Das
bedeutet, dass ein Entschluss nicht leichtfertig getroffen wird, sondern aus einer geleisteten Vorarbeit resultiert, die
in einem intensiven Reflexionsraum und Dialog mit allen Beteiligten stattgefunden hat. In einen solchen Prozess müssen
mindestens drei außenstehende Personen involviert sein. Das Awareness-Team ist sich bewusst, dass ein Ausschluss eine
drastische Maßnahme ist, z.B. für Menschen die diesen Ort als ihr Zuhause anerkennen, daher sollte diese Handlung immer
sensibel durchdacht und andere Optionen in Erwägung gezogen werden. Diese Herangehensweise bedarf allerdings, dass dem
Awareness-Team Vertrauen von den Menschen vor Ort entgegengebracht wird und die Handlungen nicht aus Prinzip in Frage
gestellt werden. Das Awareness-Team kann also – ähnlich einem Hausrecht – einen Ausschluss beschließen. Das
Camp-Security-Team kann bei Bedarf bei der Durchsetzung unterstützen.

Auch die Polizei schließt durch Repressionsgefahr Menschen aus. Daher werden wir sie nicht um Unterstützung bei der
Durchsetzung eines Ausschlusses bitten, es sei denn die Gefahr durch die auszuschließende Person ist deutlich höher als
durch die Polizei.

## Wie ist die Awareness-Struktur aufgebaut?
Die Awareness-Struktur setzt sich aus einer Koordination und den Awareness-Teams zusammen.

Während dem Camp wird die Awareness-Koordination durchgehend telefonisch erreichbar sein.

Nach dem Camp ist die Koordination bis zum 17.09 von 12 bis 18 Uhr telefonisch erreichbar.

Außerdem ist die Koordination unter der Email awareness_noiaa@riseup.net erreichbar.

Nach einem Onboarding und einer Schulung kannst du in die Koordination eintreten. Nach zwei Schichten im Awareness-Team
kannst du die aktuelle Koordination bei Wunsch und Bedarf auch unterstützen.

Die Awareness-Teams entstehen erst auf dem Camp. Ein Team besteht aus zwei Menschen. Mindestens eine Person hat an einer
mehrstündige Schulung zum Awareness-Konzept (dieses Dokument) und Awareness-Grundlagen teilgenommen (oder bereits eine
erste Schicht auf dem Camp absolviert), eine weitere Person bringt eine zweite Perspektive mit selbsteingeschätzt
ausreichender Erfahrung und der Lösung des Awareness-Konzept-Leserätsels mit.

Alle Awareness-Teams sind nach Möglichkeit nicht rein cis-männlich. Es ist auch geplant ein Deaf-Awareness-Team zu
bilden.

Zu unterschiedlichen Zeiten werden unterschiedlich viele Awareness-Teams eingesetzt. Um Überlastung vorzubeugen kann es
sein, dass keine Awareness-Teams aktiv sind, zum Beispiel in der Nacht. In Notfällen ist dann aber die
Awareness-Koordination am Telefon erreichbar.

Die Awareness-Teams sind in Schichten von 4h aktiv. Wenn gerade nicht ausreichend Menschen für eine Awareness-Schicht
verfügbar sind, dann gibt es keine aktiven Awareness-Teams. Das erste Awareness-Team besetzt das Awareness-Zelt und ist
dort ansprechbar. Weitere Awareness-Teams gehen als mobile Teams in lila Westen über das Camp und sind ansprechbar.

Die Koordination ist 8h aktiv. Die Übernahme und Übergabe von Schichten wird von der Koordination betreut. Als Teil der
Awareness-Koordination übernimmst du auch mindestens eine Koordinations-Schicht.

Bei der Arbeit mit betroffenen Personen bleibt der Name der betroffenen Person vertraulich im angesprochenen
Awareness-Team und ggf. der Awareness-Koordination. Im Team wird anonymisiert über Fälle gesprochen, die auch nach
Übergabe der Verantwortung an nachfolgende Teams relevant bleiben.

### Erste Hilfe
Falls du eine medizinische Versorgung benötigst, wende dich an den Sanitätsbereich. Dort können wir eine Erstversorgung
organisieren sowie Hinweise zu Sanitäter*innen, Krankenhäusern und Apotheken geben.

Notfälle müssen extern von Ärzt*innen versorgt werden.

### Barrierearmut
Das Gelände des Camps ist weitestgehend barrierearm. Es wird barrierearme Toiletten geben, den genauen Ort teilen wir
dir vor Beginn des Camps mit.

Für einige Veranstaltungen stellen wir Gebärdensprachenverdolmetschung zur Verfügung, bitte hab Verständnis, wenn dies
nicht für alle Veranstaltungen möglich ist.

Wenn du eine bestimmte Veranstaltung besuchen willst und dafür Gebärdendolmetschen brauchst, melde dich möglichst früh
bei per eMail uns unter awareness_noiaa@riseup.net oder beim Deaf-Space.

Wir bemühen uns um gute Ausleuchtung der sozialen Bereiche, so dass dort Unterhaltungen in Gebärdensprachen immer
möglich sind.

Leider ist die Campfläche eine Wiese, sodass das Gelände nicht besonders gut für Rollstühle geeignet ist. Wir bemühen
uns, die Hauptwege so vorzubereiten, dass sie mit dem Rollstuhl befahren werden können.

Wir statten die Wege auch mit Orientierungshilfen für Menschen mit Sehbehinderung aus. Wichtige Schilder werden auch in
Braille-Schrift zur Verfügung stehen.

Falls du Allergien hast, melde dich am besten vor Beginn des Camps bei uns unter awareness_noiaa@riseup.net damit wir
der (absolut genialen) Koch-Crew Bescheid geben können.

Für alle auftretenden Hürden gilt, melde dich bei uns (awareness_noiaa@riseup.net oder 0152 12415641), wir bemühen uns
dir eine Hilfestellung zu organisieren.

### Übersetzung
Die meisten Vorträge finden auf deutsch statt, einige andere werden auf englisch, spanisch oder anderen Sprachen
gehalten. Leider können wir nicht alle Veranstaltungen übersetzen. Wir bemühen uns im Bedarfsfall Flüsterübersetzungen
zu organisieren.

Wenn Du selber mehrere Sprachen sprichst und bereit bist, in den Workshops Flüsterübersetzungen oder
Konsekutiv-Übersetzungen zu übernehmen, trage dich ins online Helfi-Tool oder vor Ort beim Infopoint ein.

### Antirepression
Out of Action

Es gibt vor Ort eine Out of Action-Struktur mit Zelt, an die du dich wenden kannst, wenn du im Rahmen einer Aktion
Repressionen erleiden musstest und es dir nicht gut geht.

Weitere Infos unter https://outofaction.blackblogs.org/?page_id=1091

### EA (Ermittlungsausschuss)
Der Ermittlungsausschuss wird von der Roten Hilfe München gestellt und unterstützt Menschen die im Rahmen ihrer
politischen Aktionen Stress mit Polizei und/oder Justiz haben.

Der EA ist telefonisch erreichbar unter 089 448 9638 und per Mail unter ea-iaa-muc@riseup.net, wenn es Ingewahrsamnahmen
oder Polizeiübergriffe gibt und versucht einen Überblick darüber zu behalten, dass alle wieder frei gelassen werden.
Wenn nötig vermittelt der EA Anwält*innen.

Weitere Infos unter: https://rhmuc.noblogs.org/ea-iaa/

### Camp Spaces
Innerhalb der Fläche für private Zelte wird es jeweils ein BIPoC, ein FLINTA* und ein Queer Camp geben, die von den
entsprechenden Personen genutzt werden KÖNNEN, aber nicht MÜSSEN. Diese Camps sind nicht öffentlich gekennzeichnet – die
Flächen können am Infopoint und im Awarenesszelt erfragt werden. Wenn es von der Fläche her möglich ist, werden sie sich
in Teilen überschneiden. Wenn du dich diesen Gruppen nicht zugehörig fühlst, frage bitte nicht nach, wo sie sind.

## Drogen
Als konsumierende Person bist du selbst dafür verantwortlich, dass die Grenzen deiner Mitmenschen nicht überschritten
werden.

Wir stellen koffein- und zuckerhaltige Getränke zur Verfügung, aber keinen Alkohol oder Tabak. Es gibt drogenarme
Bereiche auf dem Camp, in denen nicht konsumiert werden soll – kein Trinken und kein Rauchen: Es gibt drogenarme
Bereiche auf dem Camp, in denen nicht konsumiert werden soll – kein Trinken und kein Rauchen: Das sind grundsätzlich die
Campingplätze, wo es deine zeltenden Nachbar:innen stören könnte, in den Programmzelten und SafeR-spaces und im
Essbereich.

Entsorge bitte grundsätzlich deine Kippenstummel in (Hand-)Aschenbechern und im Müll. Bitte halte das Gelände sauber und
nimm Rücksicht. (E-)Zigaretten sind hier keine Ausnahme. Wenn unsere Auflagen es zulassen, halten wir aber niemanden
davon ab, Konsumgüter mit aufs Camp zu nehmen.

Sei dir bitte im Klaren: ohne Alkohol und bestimmte bewusstseinserweiternde Substanzen bleibt uns am nächsten Tag mehr
Energie für die Dinge für die wir einstehen. Außerdem trägt der Konsum von Alkohol häufig zu nächtlichen
Lärmbelästigungen und Übergriffen bei. Das gesamte Camp ist als politische Versammlung angemeldet und alleine deshalb
solltest du immer einen klaren Kopf behalten um jederzeit verantwortungsbewusst für dich und für Andere handeln zu
können!

## Fotografieren und Filmen
Bitte Menschen nicht ungefragt fotografieren oder filmen! Wenn Personen vor einer Aufnahme nicht gefragt wurden, dann
ist die Aufnahme unmittelbar zu löschen.

## Kontakt
   Komme gern am Awareness-Zelt vorbei, sprich unsere Laufschicht an.

Rufe uns gerne unter 0152 12415641 an oder schreib uns unter awareness_noiaa@riseup.net
