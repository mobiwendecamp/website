---
title: "Awareness concept"
description: "In our Awarness concept Bla"
---


> Disclaimer
> The awareness concept can constantly change. We look forward to your feedback and criticism. The concept
> was written by the Awareness AG and was not decided upon in consensus with the entire camp organization due to time constraints
> been.

## Short version

We want to build the Munich mobility transition camp as a “safeR” space, i.e. a place where there is significantly less
Discrimination, more reflection and a more harmonious coexistence than currently exists in our society
norm is. To achieve this, we demand a learning and open attitude from everyone. We meet with the knowledge that we
On a structural level, they are all different and cross-border, and share the goal of fewer injuries
cause.

Above all, we encourage you to criticize. Criticism should generally be taken seriously. So we can
braver to face the fear of defensive reactions to one's own criticism. Anyone who expresses criticism usually has this
Need for collective betterment, and that benefits us all. Criticism can also be an act of appreciation
be, especially if we listen to those affected.

There is a FLINTA* tent, a BIPoC tent and a tent for people with disabilities, which only include the respective groups
have access. It is left to democratic self-government.


